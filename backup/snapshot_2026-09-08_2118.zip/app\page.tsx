"use client";

import {
  Dispatch,
  Fragment,
  ReactNode,
  SetStateAction,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Account,
  CHART_OF_ACCOUNTS,
  CONTRACTOR_EXPENSE,
  ITEM_MAP,
  Movement,
  OpeningBalances,
  PAYMENT_MAP,
  POSTABLE_ACCOUNTS,
  UNMAPPED_ITEMS,
  YearOpening,
  accountName,
  availableYears,
  buildAdvances,
  buildBalanceSheet,
  buildCashFlow,
  buildEquityStatement,
  buildIncomeStatement,
  buildLedger,
  buildTrialBalance,
  cashPerAccounts,
  computeTotals,
  contractPayments,
  deriveEntry,
  describePeriod,
  fullYearPeriod,
  isFullYear,
  movementsInPeriod,
  periodOpening,
  type Period,
  findBrokenMovements,
  fiscalYearOf,
  fmt,
  getAccount,
  isCash,
  isZero,
  itemAccount,
  monthlyExpenses,
  movementsOfYear,
  projectLifetimeAnalysis,
  nearlyEqual,
  openingOfYear,
  openingOnResultAccounts,
  openingTotals,
  projectSummary,
  rollForward,
  round3,
  sortMovements,
  unknownPaymentMethods,
  unlinkedContractorMovements,
  validate,
} from "@/lib/accounting";
import { amountInWords } from "@/lib/arabic-numbers";
import {
  AUDIT_LIMIT,
  AuditAction,
  AuditEntity,
  AuditEntry,
  appendEntry,
  emptyAuditFilter,
  filterAudit,
  formatAuditTime,
  makeEntry,
} from "@/lib/audit";
import {
  ExportTable,
  downloadText,
  safeFileName,
  toCSV,
} from "@/lib/export";
import {
  ALL_PERMISSIONS,
  PAGE_PERMISSION,
  PERMISSION_CATALOGUE,
  Permission,
  ROLES,
  RoleKey,
  can,
  roleDefinition,
} from "@/lib/permissions";
import {
  BackupMeta,
  backupDue,
  chooseBackupFile,
  daysSince,
  linkedFileName,
  readBackupMeta,
  saveToLinkedFile,
  supportsDirectSave,
  unlinkFile,
  writeBackupMeta,
} from "@/lib/file-backup";
import {
  CompanyProfile,
  Contractor,
  Installment,
  Material,
  MaterialReceipt,
  Project,
  User,
  backupFileName,
  defaultCompany,
  hashPin,
  emptyState,
  exportBackup,
  loadState,
  newId,
  parseBackup,
  receiptCost,
  saveState,
} from "@/lib/storage";

const PAGES = [
  "الرئيسية",
  "إدخال حركة",
  "جدول الحركات",
  "القيود اليومية",
  "دفتر الأستاذ",
  "ميزان المراجعة",
  "القوائم المالية",
  "التقارير",
  "المشاريع",
  "المقاولون",
  "اعتماد المراحل",
  "متابعة السلف",
  "استلام المواد",
  "دليل الحسابات",
  "الأرصدة الافتتاحية",
  "المستخدمون",
  "سجل التدقيق",
  "الإعدادات",
];

const PEOPLE = [
  "طارق الأسد",
  "محمد ششتري",
  "ذياب الخميس",
  "مصطفى الأنصاري",
  "م. عبدالعزيز",
  "سامي الأسد",
  "م. نوح",
  "البنك",
];

const MOVEMENT_TYPES = [
  "مصروف",
  "إيرادات",
  "إيداع",
  "سلفة",
  "سداد سلفة",
  "تحويل",
  "شراء أصل",
  "عهد موظفين",
];

export default function HomeV2() {
  const [page, setPage] = useState("الرئيسية");
  const [loaded, setLoaded] = useState(false);
  const [loadErrors, setLoadErrors] = useState<string[]>([]);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [movements, setMovements] = useState<Movement[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [contractors, setContractors] = useState<Contractor[]>([]);
  const [openingBalances, setOpeningBalances] = useState<OpeningBalances>({});
  const [materials, setMaterials] = useState<Material[]>([]);
  const [materialReceipts, setMaterialReceipts] = useState<MaterialReceipt[]>([]);
  const [company, setCompany] = useState<CompanyProfile>(defaultCompany());
  const [year, setYear] = useState<number>(0);
  const [period, setPeriod] = useState<Period>(fullYearPeriod());
  /** الحركة المطلوب طباعة سند لها */
  const [voucherFor, setVoucherFor] = useState<Movement | null>(null);
  const [backupMeta, setBackupMeta] = useState<BackupMeta | null>(null);
  const [linkedFile, setLinkedFile] = useState<string | null>(null);
  const [backupNotice, setBackupNotice] = useState("");
  const [users, setUsers] = useState<User[]>([]);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  /** الحركة قيد التعديل — فارغة يعني إدخال حركة جديدة */
  const [editing, setEditing] = useState<Movement | null>(null);

  useEffect(() => {
    const { state, errors } = loadState();
    setMovements(state.movements);
    setProjects(state.projects);
    setContractors(state.contractors);
    setOpeningBalances(state.openingBalances);
    setMaterials(state.materials);
    setMaterialReceipts(state.materialReceipts);
    setCompany(state.company);
    setUsers(state.users);
    setAudit(state.audit);
    setLoadErrors(errors);
    setYear(availableYears(state.movements, state.openingBalances)[0]);
    setBackupMeta(readBackupMeta());
    linkedFileName().then(setLinkedFile);
    setLoaded(true);
  }, []);

  // الشاشات تتبدّل داخل الصفحة نفسها، فيبقى موضع التمرير من الشاشة السابقة.
  // كل انتقال يبدأ من أعلى الصفحة.
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, [page]);

  useEffect(() => {
    if (!loaded) return;
    setSaveError(
      saveState({
        movements,
        projects,
        contractors,
        openingBalances,
        materials,
        materialReceipts,
        company,
        users,
        audit,
      })
    );
  }, [
    movements,
    projects,
    contractors,
    openingBalances,
    materials,
    materialReceipts,
    company,
    users,
    audit,
    loaded,
  ]);

  /* -------------------------------------------------------------- */
  /* كل الأرقام تُشتق مرة واحدة، مقيّدة بالسنة المختارة               */
  /* -------------------------------------------------------------- */

  const years = useMemo(
    () => availableYears(movements, openingBalances),
    [movements, openingBalances]
  );

  const allYearMovements = useMemo(
    () => sortMovements(movementsOfYear(movements, year)),
    [movements, year]
  );

  const fiscalOpening = useMemo(
    () => openingOfYear(openingBalances, year),
    [openingBalances, year]
  );
  const openTotals = useMemo(
    () => openingTotals(fiscalOpening),
    [fiscalOpening]
  );

  /** حركات الفترة المختارة — كل الشاشات تعمل عليها */
  const yearMovements = useMemo(
    () => movementsInPeriod(allYearMovements, period),
    [allYearMovements, period]
  );

  /** افتتاحي الفترة = افتتاحي السنة + ما قبل بدايتها */
  const opening = useMemo(
    () =>
      periodOpening(
        allYearMovements,
        fiscalOpening,
        openTotals.balanced,
        period.from
      ),
    [allYearMovements, fiscalOpening, openTotals.balanced, period.from]
  );

  const totals = useMemo(
    () => computeTotals(yearMovements, opening, true),
    [yearMovements, opening]
  );

  /**
   * الميزانية تحتاج ربح السنة حتى نهاية الفترة لا ربح الفترة وحدها،
   * وإلا اختلّت المعادلة عند اختيار فترة جزئية.
   */
  const netProfitToDate = useMemo(() => {
    if (isFullYear(period)) return null;
    const toDate = movementsInPeriod(allYearMovements, {
      from: "",
      to: period.to,
    });
    return buildIncomeStatement(
      computeTotals(toDate, fiscalOpening, openTotals.balanced)
    ).netProfit;
  }, [allYearMovements, period, fiscalOpening, openTotals.balanced]);

  const broken = useMemo(
    () => findBrokenMovements(yearMovements),
    [yearMovements]
  );
  const trialBalance = useMemo(() => buildTrialBalance(totals), [totals]);
  const income = useMemo(() => buildIncomeStatement(totals), [totals]);
  const balanceSheet = useMemo(
    () => buildBalanceSheet(totals, netProfitToDate ?? income.netProfit),
    [totals, netProfitToDate, income.netProfit]
  );
  const cashFlow = useMemo(
    () => buildCashFlow(yearMovements, opening, true),
    [yearMovements, opening]
  );
  const cashByAccounts = useMemo(() => cashPerAccounts(totals), [totals]);
  const equity = useMemo(
    () => buildEquityStatement(totals, netProfitToDate ?? income.netProfit),
    [totals, netProfitToDate, income.netProfit]
  );

  const fullState = {
    movements,
    projects,
    contractors,
    openingBalances,
    materials,
    materialReceipts,
    company,
    users,
    audit,
  };

  /**
   * ما دام لا يوجد مستخدمون بعد، يعمل النظام بكامل الصلاحيات بلا تسجيل دخول.
   * أول مستخدم يُسجَّل يفعّل شاشة الدخول تلقائياً.
   */
  const activeUsers = users.filter((u) => u.active);
  const currentUser =
    activeUsers.length === 0
      ? { name: "المالك", permissions: ALL_PERMISSIONS, role: "owner" as const }
      : activeUsers.find((u) => u.id === currentUserId) ?? null;

  const allow = (permission: Permission) => can(currentUser, permission);

  /** يسجّل تغييراً في سجل التدقيق باسم المستخدم الحالي */
  const log = (
    action: AuditAction,
    entity: AuditEntity,
    summary: string,
    change?: { before?: string; after?: string }
  ) =>
    setAudit((prev) =>
      appendEntry(
        prev,
        // يُستدعى دائماً بعد التحقق من المستخدم، والاحتياط هنا لإرضاء المدقّق
        makeEntry(currentUser?.name ?? "غير معروف", action, entity, summary, change)
      )
    );

  const describeMovement = (m: Movement) =>
    `قيد ${m.entryNo} · ${m.date} · ${fmt(m.amount)} د.ك · ${
      m.description || "بلا بيان"
    } · مدين ${m.debitCode} / دائن ${m.creditCode}`;

  const visiblePages = PAGES.filter((name) => {
    const needed = PAGE_PERMISSION[name];
    return !needed || allow(needed);
  });

  /** يحفظ في الملف المرتبط، وإلا ينزّل ملفاً جديداً */
  const runBackup = async () => {
    const content = exportBackup(fullState);
    const outcome = await saveToLinkedFile(content);

    if (outcome.ok) {
      setBackupMeta(writeBackupMeta(movements.length));
      setBackupNotice(`تم الحفظ في ${outcome.name}`);
      return;
    }
    if (outcome.reason === "denied") {
      setBackupNotice("رُفض الإذن بالكتابة — اختر ملف النسخة من جديد");
      return;
    }
    downloadText(backupFileName(), content, "application/json");
    setBackupMeta(writeBackupMeta(movements.length));
    setBackupNotice("تم تنزيل النسخة إلى مجلد التنزيلات");
  };

  const due = backupDue(backupMeta, movements.length);

  /** جداول جاهزة للتصدير، مقيّدة بالسنة والفترة المعروضتين */
  const exportTables: ExportTable[] = [
    {
      name: "الحركات",
      rows: [
        ["رقم القيد", "التاريخ", "نوع الحركة", "البيان", "البند", "رقم الحساب المدين", "الحساب المدين", "رقم الحساب الدائن", "الحساب الدائن", "المبلغ", "المشروع", "الدافع/المستلم", "طريقة الدفع", "الطرف"],
        ...yearMovements.map((m) => [
          m.entryNo,
          m.date,
          m.movementType,
          m.description,
          m.itemName,
          m.debitCode,
          accountName(m.debitCode),
          m.creditCode,
          accountName(m.creditCode),
          m.amount,
          m.project,
          m.person,
          m.paymentMethod,
          m.party,
        ]),
      ],
    },
    {
      name: "ميزان المراجعة",
      rows: [
        ["رقم الحساب", "اسم الحساب", "افتتاحي مدين", "افتتاحي دائن", "حركة مدين", "حركة دائن", "ختامي مدين", "ختامي دائن"],
        ...trialBalance.rows.map((r) => [
          r.account.code,
          r.account.name,
          r.openingDebit,
          r.openingCredit,
          r.periodDebit,
          r.periodCredit,
          r.closingDebit,
          r.closingCredit,
        ]),
        [
          "",
          "الإجمالي",
          trialBalance.totals.openingDebit,
          trialBalance.totals.openingCredit,
          trialBalance.totals.periodDebit,
          trialBalance.totals.periodCredit,
          trialBalance.totals.closingDebit,
          trialBalance.totals.closingCredit,
        ],
      ],
    },
    {
      name: "قائمة الدخل",
      rows: [
        ["القسم", "رقم الحساب", "اسم الحساب", "المبلغ"],
        ...income.revenues.map((r) => ["الإيرادات", r.code, r.name, r.amount]),
        ["", "", "إجمالي الإيرادات", income.totalRevenue],
        ...income.projectCosts.map((r) => ["تكاليف المشاريع", r.code, r.name, r.amount]),
        ["", "", "إجمالي تكاليف المشاريع", income.totalProjectCosts],
        ["", "", "مجمل الربح", income.grossProfit],
        ...income.adminExpenses.map((r) => ["مصروفات إدارية", r.code, r.name, r.amount]),
        ["", "", "إجمالي المصروفات الإدارية", income.totalAdminExpenses],
        ["", "", "صافي الربح / الخسارة", income.netProfit],
      ],
    },
    {
      name: "المركز المالي",
      rows: [
        ["القسم", "رقم الحساب", "اسم الحساب", "الرصيد"],
        ...balanceSheet.assets.map((r) => ["الأصول", r.code, r.name, r.amount]),
        ["", "", "إجمالي الأصول", balanceSheet.totalAssets],
        ...balanceSheet.liabilities.map((r) => ["الخصوم", r.code, r.name, r.amount]),
        ["", "", "إجمالي الخصوم", balanceSheet.totalLiabilities],
        ...balanceSheet.equityAccounts.map((r) => ["حقوق الملكية", r.code, r.name, r.amount]),
        ["", "", "صافي نتيجة الفترة", balanceSheet.netProfit],
        ["", "", "إجمالي حقوق الملكية", balanceSheet.totalEquity],
        ["", "", "إجمالي الخصوم وحقوق الملكية", balanceSheet.totalLiabilitiesAndEquity],
      ],
    },
    {
      name: "سجل استلام المواد",
      rows: [
        ["التاريخ", "المشروع", "المادة", "الكمية", "سعر الوحدة", "التكلفة", "المستلم"],
        ...materialReceipts
          .filter((r) => r.fiscalYear === year)
          .map((r) => [
            r.date,
            r.project,
            r.material,
            r.quantity,
            r.unitPrice ?? "",
            r.unitPrice == null ? "" : round3(r.quantity * r.unitPrice),
            r.receivedBy,
          ]),
      ],
    },
  ];

  const exportTable = (table: ExportTable) => {
    downloadText(
      safeFileName([table.name, String(year), describePeriod(period, year)], "csv"),
      toCSV(table.rows)
    );
  };

  if (!loaded) {
    return (
      <main dir="rtl" className="p-8 text-slate-500">
        جارٍ تحميل البيانات…
      </main>
    );
  }

  if (!currentUser) {
    return (
      <LoginScreen
        company={company}
        users={activeUsers}
        onLogin={(id) => {
          setCurrentUserId(id);
          const who = activeUsers.find((u) => u.id === id);
          setAudit((prev) =>
            appendEntry(
              prev,
              makeEntry(
                who?.name ?? "?",
                "دخول",
                "جلسة",
                `تسجيل دخول — ${who?.jobTitle || roleDefinition(who?.role ?? "custom").label}`
              )
            )
          );
        }}
      />
    );
  }

  return (
    <main dir="rtl" className="min-h-screen bg-slate-100 text-slate-900">
      {/* الإخفاء على الغلاف الداخلي لا على main، وإلا اختفى السند معه */}
      <div
        className={`flex min-h-screen ${
          voucherFor ? "hide-when-printing" : ""
        }`}
      >
        {/* القائمة ثابتة على الشاشة: الجداول طويلة، ولولا التثبيت لاختفت
            وسيلة التنقّل عند النزول. self-start ضروري لأن عناصر flex
            تتمدّد بالكامل فلا يبقى للـ sticky مجال. */}
        <aside className="sticky top-0 h-screen w-72 shrink-0 self-start overflow-y-auto bg-slate-900 p-6 text-white no-print">
          <div className="mb-4">
            <h1 className="text-xl font-bold">Theyab Accounting</h1>
            <p className="mt-1 text-xs text-slate-400">النظام المالي والمحاسبي</p>
          </div>

          <div className="mb-4 rounded-lg bg-slate-800 p-3 text-sm">
            <div className="font-bold">{currentUser.name}</div>
            <div className="text-xs text-slate-400">
              {"jobTitle" in currentUser && currentUser.jobTitle
                ? currentUser.jobTitle
                : roleDefinition(currentUser.role).label}
            </div>
            {activeUsers.length > 0 && (
              <button
                onClick={() => {
                  log("خروج", "جلسة", "تسجيل خروج");
                  setCurrentUserId(null);
                }}
                className="mt-2 w-full rounded bg-slate-700 px-3 py-1 text-xs hover:bg-slate-600"
              >
                تسجيل الخروج
              </button>
            )}
          </div>

          <nav className="space-y-1">
            {visiblePages.map((name) => (
              <button
                key={name}
                onClick={() => setPage(name)}
                className={`w-full rounded-lg px-4 py-2 text-right text-sm transition ${
                  page === name
                    ? "bg-blue-600 font-bold text-white"
                    : "hover:bg-slate-800"
                }`}
              >
                {name}
              </button>
            ))}
          </nav>
        </aside>

        <section className="min-w-0 flex-1 p-8 print-area">
          {/* ترويسة المطبوعات — لا تظهر على الشاشة */}
          <PrintHeader
            company={company}
            title={page}
            year={year}
            period={describePeriod(period, year)}
          />

          <header className="mb-6 flex flex-wrap items-center justify-between gap-4 no-print">
            <div>
              <h2 className="text-3xl font-bold">
                {page === "الرئيسية" ? "لوحة المعلومات الرئيسية" : page}
              </h2>
              <p className="mt-2 text-slate-500">
                {yearMovements.length} حركة في السنة المالية {year}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => window.print()}
                className="rounded-xl bg-slate-900 px-5 py-3 font-bold text-white"
              >
                🖨 طباعة الصفحة
              </button>
              <label className="text-sm font-medium">السنة المالية</label>
              <select
                value={year}
                onChange={(e) => {
                  setYear(Number(e.target.value));
                  // تواريخ الفترة تخص سنتها، فتُمسح عند تبديل السنة
                  setPeriod(fullYearPeriod());
                }}
                className="rounded-xl border border-slate-300 bg-white px-5 py-3 font-bold shadow-sm"
              >
                {years.map((y) => (
                  <option key={y} value={y}>
                    {y}
                  </option>
                ))}
              </select>
            </div>
          </header>

          <PeriodBar year={year} period={period} setPeriod={setPeriod} />

          {!isFullYear(period) && (
            <Banner tone="warn">
              التقارير مقيّدة بالفترة: <b>{describePeriod(period, year)}</b> —{" "}
              {yearMovements.length} حركة من أصل {allYearMovements.length} في
              السنة. الأرصدة الافتتاحية المعروضة هي أرصدة بداية الفترة لا بداية
              السنة.
            </Banner>
          )}

          {due.due && (
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm font-medium text-amber-900 no-print">
              <span>
                {backupMeta
                  ? `مضى ${due.days} يوماً على آخر نسخة احتياطية${
                      due.added ? ` وأُضيفت ${due.added} حركة بعدها` : ""
                    }.`
                  : "لم تأخذ نسخة احتياطية بعد — بياناتك في هذا المتصفح وحده."}
              </span>
              <button
                onClick={runBackup}
                className="rounded-lg bg-amber-900 px-5 py-2 font-bold text-white"
              >
                احفظ الآن
              </button>
            </div>
          )}

          {backupNotice && (
            <Banner tone="ok">
              {backupNotice}
              {backupMeta && ` — ${new Date(backupMeta.at).toLocaleString("ar")}`}
            </Banner>
          )}

          {loadErrors.map((error) => (
            <Banner key={error} tone="error">
              {error}
            </Banner>
          ))}
          {saveError && <Banner tone="error">{saveError}</Banner>}

          {broken.length > 0 && (
            <Banner tone="warn">
              <b>{broken.length}</b> حركة في {year} لا تُنتج قيداً صالحاً، وهي
              مستبعدة من التقارير.{" "}
              <button onClick={() => setPage("الإعدادات")} className="underline">
                عرض التفاصيل
              </button>
            </Banner>
          )}

          {!openTotals.balanced && !isZero(openTotals.debit + openTotals.credit) && (
            <Banner tone="warn">
              أرصدة {year} الافتتاحية غير متوازنة (مدين {fmt(openTotals.debit)}{" "}
              مقابل دائن {fmt(openTotals.credit)}) — لم تُعتمد في أي تقرير.
            </Banner>
          )}

          {page === "الرئيسية" && (
            <Dashboard
              year={year}
              income={income}
              balanceSheet={balanceSheet}
              cash={cashByAccounts}
              trialBalance={trialBalance}
              movementCount={yearMovements.length}
            />
          )}

          {page === "إدخال حركة" && (
            <MovementForm
              year={year}
              projects={projects}
              contractors={contractors}
              editing={editing}
              nextEntryNo={
                yearMovements.reduce((max, m) => Math.max(max, m.entryNo), 1000) + 1
              }
              onSave={(movement) => {
                setMovements((prev) => [...prev, movement]);
                log("إنشاء", "حركة", describeMovement(movement));
              }}
              onUpdate={(movement) => {
                const old = movements.find((m) => m.id === movement.id);
                setMovements((prev) =>
                  prev.map((m) => (m.id === movement.id ? movement : m))
                );
                log("تعديل", "حركة", `قيد ${movement.entryNo}`, {
                  before: old ? describeMovement(old) : undefined,
                  after: describeMovement(movement),
                });
                setEditing(null);
              }}
              onCancelEdit={() => setEditing(null)}
            />
          )}

          {page === "جدول الحركات" && (
            <MovementsTable
              movements={yearMovements}
              onEdit={(movement) => {
                setEditing(movement);
                setPage("إدخال حركة");
              }}
              onVoucher={setVoucherFor}
              onDelete={(id) => {
                const gone = movements.find((m) => m.id === id);
                setMovements((prev) => prev.filter((m) => m.id !== id));
                if (gone) {
                  log("حذف", "حركة", `قيد ${gone.entryNo}`, {
                    before: describeMovement(gone),
                  });
                }
              }}
            />
          )}

          {page === "القيود اليومية" && <JournalPage movements={yearMovements} />}

          {page === "دفتر الأستاذ" && (
            <LedgerPage movements={yearMovements} totals={totals} />
          )}

          {page === "ميزان المراجعة" && (
            <TrialBalancePage report={trialBalance} year={year} />
          )}

          {page === "القوائم المالية" && (
            <FinancialsPage
              income={income}
              balanceSheet={balanceSheet}
              cashFlow={cashFlow}
              cashByAccounts={cashByAccounts}
              equity={equity}
            />
          )}

          {page === "التقارير" && (
            <ReportsPage
              movements={yearMovements}
              allMovements={movements}
              year={year}
              income={income}
            />
          )}

          {page === "المشاريع" && (
            <ProjectsPage
              projects={projects}
              movements={movements}
              year={year}
              setProjects={setProjects}
              openProject={(p) => setPage("حركات المشروع:" + p.name)}
            />
          )}

          {page.startsWith("حركات المشروع:") && (
            <ProjectMovementsPage
              projectName={page.slice("حركات المشروع:".length)}
              movements={movements}
              year={year}
              onBack={() => setPage("المشاريع")}
            />
          )}

          {page === "المقاولون" && (
            <ContractorsPage
              contractors={contractors}
              projects={projects}
              movements={yearMovements}
              setContractors={setContractors}
              onLink={(movementId, contractNumber, installmentNumber) =>
                setMovements((prev) =>
                  prev.map((m) =>
                    m.id === movementId
                      ? { ...m, contractNumber, installmentNumber }
                      : m
                  )
                )
              }
            />
          )}

          {page === "اعتماد المراحل" && (
            <ApprovalsPage
              contractors={contractors}
              projects={projects}
              movements={movements}
              approverName={currentUser.name}
              canApprove={allow("contracts.approve")}
              setContractors={setContractors}
              onLog={log}
            />
          )}

          {page === "متابعة السلف" && (
            <AdvancesPage
              movements={yearMovements}
              year={year}
              onEdit={(movement) => {
                setEditing(movement);
                setPage("إدخال حركة");
              }}
            />
          )}

          {page === "استلام المواد" && (
            <MaterialsPage
              year={year}
              projects={projects}
              materials={materials}
              receipts={materialReceipts.filter((r) => r.fiscalYear === year)}
              setMaterials={setMaterials}
              setReceipts={setMaterialReceipts}
            />
          )}

          {page === "المستخدمون" && (
            <UsersPage
              users={users}
              setUsers={setUsers}
              currentUserId={currentUserId}
            />
          )}

          {page === "سجل التدقيق" && (
            <AuditPage audit={audit} onExport={exportTable} />
          )}

          {page === "دليل الحسابات" && <ChartPage />}

          {page === "الأرصدة الافتتاحية" && (
            <OpeningPage
              year={year}
              opening={opening}
              totals={openTotals}
              setYearOpening={(next) =>
                setOpeningBalances((prev) => ({ ...prev, [String(year)]: next }))
              }
            />
          )}

          {page === "الإعدادات" && (
            <SettingsPage
              year={year}
              years={years}
              state={{
                movements,
                projects,
                contractors,
                openingBalances,
                materials,
                materialReceipts,
                company,
                users,
                audit,
              }}
              broken={broken}
              paymentGaps={unknownPaymentMethods(yearMovements)}
              onFix={(movement) => {
                setEditing(movement);
                setPage("إدخال حركة");
              }}
              onRollForward={() => {
                const next = rollForward(totals, income.netProfit);
                const target = String(year + 1);
                if (
                  !window.confirm(
                    `ترحيل ${Object.keys(next).length} رصيداً من إقفال ${year} إلى افتتاحي ${
                      year + 1
                    }؟\n\nسيحل محل أي أرصدة افتتاحية مسجّلة لسنة ${year + 1}.`
                  )
                ) {
                  return;
                }
                setOpeningBalances((prev) => ({ ...prev, [target]: next }));
                log(
                  "ترحيل",
                  "أرصدة افتتاحية",
                  `ترحيل أرصدة إقفال ${year} إلى افتتاحي ${year + 1} — ${
                    Object.keys(next).length
                  } حساباً · صافي النتيجة ${fmt(income.netProfit)} د.ك`
                );
              }}
              onImport={(next) => {
                setMovements(next.movements);
                setProjects(next.projects);
                setContractors(next.contractors);
                setOpeningBalances(next.openingBalances);
                setMaterials(next.materials);
                setMaterialReceipts(next.materialReceipts);
                setYear(availableYears(next.movements, next.openingBalances)[0]);
                log(
                  "استيراد",
                  "بيانات النظام",
                  `استبدال كامل للبيانات — ${next.movements.length} حركة · ${next.projects.length} مشروع · ${next.contractors.length} عقد`,
                  { before: `${movements.length} حركة قبل الاستيراد` }
                );
              }}
              company={company}
              setCompany={setCompany}
              backupMeta={backupMeta}
              linkedFile={linkedFile}
              onRunBackup={runBackup}
              onLinkFile={async () => {
                try {
                  const name = await chooseBackupFile(backupFileName());
                  if (name) {
                    setLinkedFile(name);
                    await runBackup();
                  }
                } catch {
                  // المستخدم أغلق نافذة الاختيار
                }
              }}
              onUnlinkFile={async () => {
                await unlinkFile();
                setLinkedFile(null);
              }}
              exportTables={exportTables}
              onExport={exportTable}
              onImportMaterials={(nextMaterials, nextReceipts) => {
                // دمج بالمعرّف: يُبقي ما عندك ويضيف الجديد فقط
                setMaterials((prev) => {
                  const ids = new Set(prev.map((m) => m.id));
                  const names = new Set(prev.map((m) => m.name));
                  return [
                    ...prev,
                    ...nextMaterials.filter(
                      (m) => !ids.has(m.id) && !names.has(m.name)
                    ),
                  ];
                });
                setMaterialReceipts((prev) => {
                  const ids = new Set(prev.map((r) => r.id));
                  return [...prev, ...nextReceipts.filter((r) => !ids.has(r.id))];
                });
              }}
            />
          )}
        </section>
      </div>

      {voucherFor && (
        <VoucherSheet
          movement={voucherFor}
          company={company}
          onClose={() => setVoucherFor(null)}
        />
      )}
    </main>
  );
}

/* ================================================================== */
/* عناصر مشتركة                                                        */
/* ================================================================== */

function Banner({
  tone,
  children,
}: {
  tone: "ok" | "warn" | "error";
  children: ReactNode;
}) {
  const styles = {
    ok: "bg-green-50 text-green-800 border-green-200",
    warn: "bg-amber-50 text-amber-900 border-amber-200",
    error: "bg-red-50 text-red-800 border-red-200",
  }[tone];
  return (
    <div className={`mb-4 rounded-xl border px-4 py-3 text-sm font-medium ${styles}`}>
      {children}
    </div>
  );
}

function Panel({
  title,
  subtitle,
  children,
}: {
  title?: string;
  subtitle?: string;
  children: ReactNode;
}) {
  return (
    <div className="mb-6 rounded-2xl bg-white p-6 shadow-sm">
      {title && <h3 className="text-xl font-bold">{title}</h3>}
      {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      <div className={title ? "mt-5" : ""}>{children}</div>
    </div>
  );
}

function Money({ value, bold }: { value: number; bold?: boolean }) {
  return (
    <span
      className={`tabular-nums ${bold ? "font-bold" : ""} ${
        value < 0 ? "text-red-600" : ""
      }`}
    >
      {fmt(value)}
    </span>
  );
}

function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium">{label}</label>
      {children}
      {hint && <p className="mt-1 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-slate-300 px-4 py-3 focus:border-blue-500 focus:outline-none";

const Th = ({ children }: { children: ReactNode }) => (
  <th className="px-4 py-3 text-right font-bold">{children}</th>
);

const Td = ({
  children,
  colSpan,
  className = "",
}: {
  children: ReactNode;
  colSpan?: number;
  className?: string;
}) => (
  <td colSpan={colSpan} className={`px-4 py-3 ${className}`}>
    {children}
  </td>
);

const Empty = ({ children }: { children: ReactNode }) => (
  <p className="py-8 text-center text-slate-500">{children}</p>
);

const accountLabel = (code: string) =>
  code ? `${code} — ${getAccount(code)?.name ?? "?"}` : "—";

const todayISO = () => new Date().toISOString().slice(0, 10);

/* ================================================================== */
/* شريط الفترة                                                         */
/* ================================================================== */

const pad2 = (n: number) => String(n).padStart(2, "0");
const lastDay = (year: number, month: number) =>
  new Date(Date.UTC(year, month, 0)).getUTCDate();

function PeriodBar({
  year,
  period,
  setPeriod,
}: {
  year: number;
  period: Period;
  setPeriod: Dispatch<SetStateAction<Period>>;
}) {
  const [open, setOpen] = useState(false);

  const monthRange = (month: number): Period => ({
    from: `${year}-${pad2(month)}-01`,
    to: `${year}-${pad2(month)}-${pad2(lastDay(year, month))}`,
  });

  const quarter = (q: number): Period => ({
    from: `${year}-${pad2(q * 3 - 2)}-01`,
    to: `${year}-${pad2(q * 3)}-${pad2(lastDay(year, q * 3))}`,
  });

  const presets: [string, Period][] = [
    ["السنة كاملة", fullYearPeriod()],
    ["الربع الأول", quarter(1)],
    ["الربع الثاني", quarter(2)],
    ["الربع الثالث", quarter(3)],
    ["الربع الرابع", quarter(4)],
    ["النصف الأول", { from: `${year}-01-01`, to: `${year}-06-30` }],
    ["النصف الثاني", { from: `${year}-07-01`, to: `${year}-12-31` }],
  ];

  const active = (p: Period) => p.from === period.from && p.to === period.to;

  return (
    <div className="mb-5 rounded-xl border border-slate-200 bg-white p-4 no-print">
      <div className="flex flex-wrap items-center gap-2">
        <span className="ml-2 text-sm font-bold">الفترة:</span>

        {presets.map(([label, value]) => (
          <button
            key={label}
            onClick={() => setPeriod(value)}
            className={`rounded-lg px-3 py-2 text-sm font-medium ${
              active(value)
                ? "bg-blue-600 text-white"
                : "bg-slate-100 hover:bg-slate-200"
            }`}
          >
            {label}
          </button>
        ))}

        <select
          value=""
          onChange={(e) => {
            if (e.target.value) setPeriod(monthRange(Number(e.target.value)));
          }}
          className="rounded-lg bg-slate-100 px-3 py-2 text-sm font-medium"
        >
          <option value="">شهر محدّد…</option>
          {MONTH_NAMES.map((name, i) => (
            <option key={name} value={i + 1}>
              {name}
            </option>
          ))}
        </select>

        <button
          onClick={() => setOpen(!open)}
          className={`rounded-lg px-3 py-2 text-sm font-medium ${
            open ? "bg-slate-900 text-white" : "bg-slate-100 hover:bg-slate-200"
          }`}
        >
          فترة مخصّصة
        </button>

        <span className="mr-auto text-sm text-slate-500">
          {describePeriod(period, year)}
        </span>
      </div>

      {open && (
        <div className="mt-4 grid grid-cols-1 gap-4 border-t border-slate-200 pt-4 md:grid-cols-3">
          <Field label="من تاريخ">
            <input
              type="date"
              value={period.from}
              onChange={(e) =>
                setPeriod((p) => ({ ...p, from: e.target.value }))
              }
              className={inputClass}
            />
          </Field>
          <Field label="إلى تاريخ">
            <input
              type="date"
              value={period.to}
              onChange={(e) => setPeriod((p) => ({ ...p, to: e.target.value }))}
              className={inputClass}
            />
          </Field>
          <div className="flex items-end">
            <button
              onClick={() => setPeriod(fullYearPeriod())}
              className="rounded-lg bg-slate-200 px-5 py-3 font-bold"
            >
              مسح الفترة
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/* الطباعة                                                             */
/* ================================================================== */

/** ترويسة تظهر أعلى كل مطبوعة فقط — مخفية على الشاشة */
function PrintHeader({
  company,
  title,
  year,
  period,
}: {
  company: CompanyProfile;
  title: string;
  year: number;
  period: string;
}) {
  return (
    <div className="print-only mb-4 border-b-2 border-black pb-3">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          {company.logo && (
            // صورة الشعار مخزّنة كـ data URL فتُطبع بلا اتصال
            // eslint-disable-next-line @next/next/no-img-element
            <img src={company.logo} alt="" style={{ height: 56 }} />
          )}
          <div>
            <div style={{ fontSize: "16pt", fontWeight: 700 }}>
              {company.name}
            </div>
            {company.nameEn && (
              <div style={{ fontSize: "9pt" }}>{company.nameEn}</div>
            )}
            <div style={{ fontSize: "8pt" }}>
              {[company.address, company.phone, company.email]
                .filter(Boolean)
                .join(" · ")}
            </div>
          </div>
        </div>

        <div style={{ textAlign: "left", fontSize: "9pt" }}>
          <div style={{ fontSize: "13pt", fontWeight: 700 }}>{title}</div>
          <div style={{ fontWeight: 700 }}>{period}</div>
          <div>تاريخ الطباعة: {todayISO()}</div>
          {company.crNumber && <div>س.ت: {company.crNumber}</div>}
        </div>
      </div>
    </div>
  );
}

/** نوع السند: صرف إن خرجت النقدية، قبض إن دخلت */
function voucherKind(movement: Movement): "صرف" | "قبض" | null {
  if (isCash(movement.creditCode)) return "صرف";
  if (isCash(movement.debitCode)) return "قبض";
  return null;
}

function VoucherSheet({
  movement,
  company,
  onClose,
}: {
  movement: Movement;
  company: CompanyProfile;
  onClose: () => void;
}) {
  const kind = voucherKind(movement);
  const isPayment = kind === "صرف";

  // في سند الصرف: الطرف هو الجهة المدينة · في سند القبض: الجهة الدائنة
  const counterparty =
    movement.party ||
    movement.person ||
    accountLabel(isPayment ? movement.debitCode : movement.creditCode);

  const cashCode = isCash(movement.creditCode)
    ? movement.creditCode
    : movement.debitCode;

  const rows: [string, string][] = [
    ["رقم السند", String(movement.entryNo)],
    ["التاريخ", movement.date],
    ["السنة المالية", String(movement.fiscalYear)],
    [isPayment ? "صُرف إلى" : "استُلم من", counterparty],
    ["طريقة الدفع", movement.paymentMethod || "—"],
    ["المشروع", movement.project || "—"],
    ["البند", movement.itemName || "—"],
    [
      isPayment ? "من حساب" : "إلى حساب",
      accountLabel(isPayment ? movement.debitCode : movement.creditCode),
    ],
    ["الحساب النقدي", accountLabel(cashCode)],
  ];

  return (
    <div
      className="voucher-sheet fixed inset-0 z-50 overflow-auto bg-slate-800/60 p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="voucher-body mx-auto max-w-3xl bg-white p-8 shadow-xl"
        style={{ minHeight: "26cm" }}
      >
        <div className="mb-6 flex justify-end gap-3 no-print">
          <button
            onClick={() => window.print()}
            className="rounded-lg bg-slate-900 px-6 py-3 font-bold text-white"
          >
            🖨 طباعة السند
          </button>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-200 px-6 py-3 font-bold"
          >
            إغلاق
          </button>
        </div>

        {/* ترويسة الشركة */}
        <div className="flex items-start justify-between gap-4 border-b-4 border-slate-900 pb-4">
          <div className="flex items-center gap-4">
            {company.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={company.logo} alt="" style={{ height: 72 }} />
            ) : (
              <div className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-slate-300 text-[10px] text-slate-400">
                الشعار
              </div>
            )}
            <div>
              <div className="text-2xl font-bold">{company.name}</div>
              {company.nameEn && (
                <div className="text-sm text-slate-600">{company.nameEn}</div>
              )}
              <div className="mt-1 text-xs text-slate-600">
                {[company.address, company.phone, company.email]
                  .filter(Boolean)
                  .join(" · ")}
              </div>
            </div>
          </div>

          <div className="text-left">
            <div className="inline-block rounded-lg border-2 border-slate-900 px-6 py-3 text-center">
              <div className="text-xl font-bold">
                {kind ? `سند ${kind}` : "سند قيد"}
              </div>
              <div className="mt-1 text-xs">
                {kind === "صرف"
                  ? "PAYMENT VOUCHER"
                  : kind === "قبض"
                  ? "RECEIPT VOUCHER"
                  : "JOURNAL VOUCHER"}
              </div>
            </div>
            <div className="mt-2 text-sm font-bold">
              رقم {movement.entryNo} / {movement.fiscalYear}
            </div>
          </div>
        </div>

        {!kind && (
          <p className="mt-4 rounded-lg border border-amber-300 bg-amber-50 px-4 py-2 text-sm">
            هذه الحركة لم تمسّ الصندوق ولا البنك، فهي قيد محاسبي لا سند صرف أو
            قبض.
          </p>
        )}

        {/* المبلغ */}
        <div className="mt-6 flex items-stretch justify-between gap-4">
          <div className="flex-1 rounded-lg border border-slate-300 p-4">
            <div className="text-xs text-slate-500">المبلغ بالحروف</div>
            <div className="mt-1 text-lg font-bold leading-relaxed">
              {amountInWords(movement.amount)}
            </div>
          </div>
          <div className="w-56 rounded-lg border-2 border-slate-900 p-4 text-center">
            <div className="text-xs text-slate-500">المبلغ</div>
            <div className="mt-1 text-3xl font-bold tabular-nums">
              {fmt(movement.amount)}
            </div>
            <div className="text-sm">د.ك</div>
          </div>
        </div>

        {/* التفاصيل */}
        <table className="mt-6 w-full text-right text-sm">
          <tbody>
            {rows.map(([label, value]) => (
              <tr key={label} className="border-b border-slate-200">
                <td className="w-44 bg-slate-50 px-4 py-3 font-bold">{label}</td>
                <td className="px-4 py-3">{value}</td>
              </tr>
            ))}
            <tr className="border-b border-slate-200">
              <td className="w-44 bg-slate-50 px-4 py-3 font-bold align-top">
                البيان
              </td>
              <td className="px-4 py-3" style={{ minHeight: "3rem" }}>
                {movement.description || "—"}
              </td>
            </tr>
          </tbody>
        </table>

        {/* القيد المحاسبي */}
        <div className="mt-6">
          <div className="mb-2 text-sm font-bold">القيد المحاسبي</div>
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <th className="border border-slate-300 px-3 py-2">رقم الحساب</th>
                <th className="border border-slate-300 px-3 py-2">اسم الحساب</th>
                <th className="border border-slate-300 px-3 py-2">مدين</th>
                <th className="border border-slate-300 px-3 py-2">دائن</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-slate-300 px-3 py-2">
                  {movement.debitCode}
                </td>
                <td className="border border-slate-300 px-3 py-2">
                  {getAccount(movement.debitCode)?.name}
                </td>
                <td className="border border-slate-300 px-3 py-2 tabular-nums">
                  {fmt(movement.amount)}
                </td>
                <td className="border border-slate-300 px-3 py-2">—</td>
              </tr>
              <tr>
                <td className="border border-slate-300 px-3 py-2">
                  {movement.creditCode}
                </td>
                <td className="border border-slate-300 px-3 py-2">
                  {getAccount(movement.creditCode)?.name}
                </td>
                <td className="border border-slate-300 px-3 py-2">—</td>
                <td className="border border-slate-300 px-3 py-2 tabular-nums">
                  {fmt(movement.amount)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* التواقيع */}
        <div className="mt-14 grid grid-cols-3 gap-8 text-center text-sm">
          {["المستلم", "المحاسب", "الاعتماد"].map((label) => (
            <div key={label}>
              <div className="mb-2 border-b border-slate-400 pb-10" />
              <div className="font-bold">{label}</div>
            </div>
          ))}
        </div>

        <div className="mt-8 text-center text-[10px] text-slate-400">
          طُبع في {todayISO()} — {company.name}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/* الرئيسية                                                            */
/* ================================================================== */

function Dashboard({
  year,
  income,
  balanceSheet,
  cash,
  trialBalance,
  movementCount,
}: {
  year: number;
  income: ReturnType<typeof buildIncomeStatement>;
  balanceSheet: ReturnType<typeof buildBalanceSheet>;
  cash: number;
  trialBalance: ReturnType<typeof buildTrialBalance>;
  movementCount: number;
}) {
  const cards = [
    { title: "إجمالي الإيرادات", value: income.totalRevenue },
    {
      title: "إجمالي المصروفات",
      value: round3(income.totalProjectCosts + income.totalAdminExpenses),
    },
    { title: "صافي الربح / الخسارة", value: income.netProfit },
    { title: "النقدية والبنوك", value: cash },
  ];

  return (
    <>
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <div key={card.title} className="rounded-2xl bg-white p-6 shadow-sm">
            <p className="text-sm text-slate-500">{card.title}</p>
            <p className="mt-4 text-2xl font-bold">
              <Money value={card.value} /> د.ك
            </p>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <Panel title={`حالة دفاتر ${year}`}>
          <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
            {[
              ["عدد الحركات", String(movementCount)],
              ["حسابات بها حركة", String(trialBalance.rows.length)],
              ["مجمل الربح", fmt(income.grossProfit)],
              ["فرق الميزانية", fmt(balanceSheet.difference)],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl border border-slate-200 p-4">
                <p className="text-sm text-slate-500">{label}</p>
                <p className="mt-1 text-xl font-bold">{value}</p>
              </div>
            ))}
          </div>

          <div className="mt-4 space-y-2">
            {trialBalance.balanced ? (
              <Banner tone="ok">✓ ميزان المراجعة متوازن</Banner>
            ) : (
              <Banner tone="error">⚠ ميزان المراجعة غير متوازن</Banner>
            )}
            {balanceSheet.balanced ? (
              <Banner tone="ok">
                ✓ الأصول ({fmt(balanceSheet.totalAssets)}) = الخصوم وحقوق الملكية
              </Banner>
            ) : (
              <Banner tone="error">
                ⚠ الميزانية غير متوازنة بفارق {fmt(balanceSheet.difference)} د.ك
              </Banner>
            )}
          </div>
        </Panel>
      </div>
    </>
  );
}

/* ================================================================== */
/* إدخال حركة                                                          */
/* ================================================================== */

const BLANK_FORM = {
  date: "",
  movementType: "",
  itemCode: "",
  paymentMethod: "",
  project: "",
  amount: "",
  person: "",
  party: "",
  description: "",
  debitCode: "",
  creditCode: "",
  manual: false,
  contractNumber: "",
  installmentNumber: "",
};

/** يملأ النموذج من حركة قائمة، ويفعّل الوضع اليدوي إن كان قيدها لا يتبع القواعد */
function formOf(movement: Movement): typeof BLANK_FORM {
  const derived = deriveEntry({
    movementType: movement.movementType,
    itemCode: movement.itemCode,
    paymentMethod: movement.paymentMethod,
  });
  const followsRules =
    derived.debitCode === movement.debitCode &&
    derived.creditCode === movement.creditCode;

  // القيد المعطوب يُفتح على الوضع اليدوي مباشرة، وإلا بقيت خانتا الحساب
  // مخفيّتين وتعذّر تصحيحه أصلاً
  const broken = !validate(movement).valid;

  return {
    date: movement.date,
    movementType: movement.movementType,
    itemCode: movement.itemCode,
    paymentMethod: movement.paymentMethod,
    project: movement.project,
    amount: String(movement.amount),
    person: movement.person,
    party: movement.party,
    description: movement.description,
    debitCode: movement.debitCode,
    creditCode: movement.creditCode,
    manual: !followsRules || broken,
    contractNumber: movement.contractNumber ?? "",
    installmentNumber: movement.installmentNumber
      ? String(movement.installmentNumber)
      : "",
  };
}

function MovementForm({
  year,
  projects,
  contractors,
  editing,
  nextEntryNo,
  onSave,
  onUpdate,
  onCancelEdit,
}: {
  year: number;
  projects: Project[];
  contractors: Contractor[];
  editing: Movement | null;
  nextEntryNo: number;
  onSave: (movement: Movement) => void;
  onUpdate: (movement: Movement) => void;
  onCancelEdit: () => void;
}) {
  const blank = BLANK_FORM;

  const [form, setForm] = useState(blank);
  const [message, setMessage] = useState("");

  // فتح حركة للتعديل يملأ النموذج بقيمها
  useEffect(() => {
    setForm(editing ? formOf(editing) : BLANK_FORM);
    setMessage("");
  }, [editing]);

  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(""), 4000);
    return () => clearTimeout(timer);
  }, [message]);

  const set = (key: keyof typeof blank, value: string | boolean) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const derived = form.manual
    ? { debitCode: form.debitCode, creditCode: form.creditCode }
    : deriveEntry({
        movementType: form.movementType,
        itemCode: form.itemCode,
        paymentMethod: form.paymentMethod,
      });

  const draft: Partial<Movement> = {
    ...form,
    ...derived,
    amount: Number(form.amount) || 0,
    installmentNumber: Number(form.installmentNumber) || undefined,
  };
  const check = validate(draft);

  const handleSave = () => {
    if (!check.valid) return;
    const item = ITEM_MAP.find((i) => i.code === form.itemCode);
    const common = {
      fiscalYear: fiscalYearOf(form.date),
      date: form.date,
      movementType: form.movementType,
      description: form.description,
      itemCode: form.itemCode,
      itemName: item?.name ?? editing?.itemName ?? "",
      debitCode: derived.debitCode,
      creditCode: derived.creditCode,
      amount: round3(Number(form.amount) || 0),
      project: form.project,
      person: form.person,
      paymentMethod: form.paymentMethod,
      party: form.party,
      contractNumber: form.contractNumber || undefined,
      installmentNumber: Number(form.installmentNumber) || undefined,
    };

    if (editing) {
      // التعديل يحافظ على المعرّف ورقم القيد حتى لا ينكسر التسلسل
      onUpdate({ ...editing, ...common });
      setMessage(`تم تعديل القيد ${editing.entryNo}`);
      return;
    }

    onSave({
      id: newId(),
      entryNo: nextEntryNo,
      ...common,
      source: "app",
    });
    setForm(blank);
    setMessage(`تم حفظ الحركة برقم قيد ${nextEntryNo}`);
  };

  const entryYear = fiscalYearOf(form.date);
  const yearMismatch = !!form.date && entryYear !== year;

  return (
    <Panel
      title={editing ? `تعديل القيد ${editing.entryNo}` : "إدخال حركة مالية جديدة"}
      subtitle={
        editing
          ? `${editing.source === "excel" ? "حركة مستوردة من الإكسل" : "حركة مُدخلة في النظام"} — رقم القيد وتاريخ الإنشاء محفوظان`
          : `رقم القيد التالي: ${nextEntryNo}`
      }
    >
      {editing && !validate(editing).valid && (
        <Banner tone="error">
          هذا قيد معطوب: {validate(editing).problem}. فُتح على الوضع اليدوي —
          صحّح الحساب المدين أو الدائن أدناه ثم احفظ.
        </Banner>
      )}

      {editing && validate(editing).valid && (
        <Banner tone="warn">
          أنت تعدّل حركة قائمة. اضغط «إلغاء التعديل» للعودة إلى إدخال حركة جديدة.
        </Banner>
      )}

      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        <Field label="التاريخ">
          <input
            type="date"
            value={form.date}
            onChange={(e) => set("date", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="نوع الحركة">
          <select
            value={form.movementType}
            onChange={(e) => set("movementType", e.target.value)}
            className={inputClass}
          >
            <option value="">اختر نوع الحركة</option>
            {MOVEMENT_TYPES.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>

        <Field
          label="البند"
          hint={
            form.itemCode
              ? `يُرحّل إلى ${accountLabel(itemAccount(form.itemCode))}`
              : undefined
          }
        >
          <select
            value={form.itemCode}
            onChange={(e) => set("itemCode", e.target.value)}
            disabled={form.manual}
            className={`${inputClass} disabled:bg-slate-100`}
          >
            <option value="">اختر البند</option>
            {ITEM_MAP.filter((i) => i.account).map((item) => (
              <option key={item.code} value={item.code}>
                {item.name} ({item.account})
              </option>
            ))}
          </select>
        </Field>

        <Field
          label="طريقة الدفع"
          hint={
            form.paymentMethod
              ? `الحساب المقابل ${accountLabel(
                  PAYMENT_MAP.find((p) => p.label === form.paymentMethod)?.account ?? ""
                )}`
              : undefined
          }
        >
          <select
            value={form.paymentMethod}
            onChange={(e) => set("paymentMethod", e.target.value)}
            disabled={form.manual}
            className={`${inputClass} disabled:bg-slate-100`}
          >
            <option value="">اختر طريقة الدفع</option>
            {PAYMENT_MAP.map((p) => (
              <option key={p.label} value={p.label}>
                {p.label} ({p.account})
              </option>
            ))}
          </select>
        </Field>

        <Field label="المشروع">
          <select
            value={form.project}
            onChange={(e) => set("project", e.target.value)}
            className={inputClass}
          >
            <option value="">بدون مشروع</option>
            {projects.map((p) => (
              <option key={p.id} value={p.name}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>

        <Field label="المبلغ (د.ك)">
          <input
            type="number"
            step="0.001"
            min="0"
            value={form.amount}
            onChange={(e) => set("amount", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="الدافع / المستلم">
          <select
            value={form.person}
            onChange={(e) => set("person", e.target.value)}
            className={inputClass}
          >
            <option value="">اختر الدافع / المستلم</option>
            {PEOPLE.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        </Field>

        <Field label="الطرف">
          <input
            type="text"
            value={form.party}
            onChange={(e) => set("party", e.target.value)}
            placeholder="اسم المورد / العميل / المقاول"
            className={inputClass}
          />
        </Field>
      </div>

      <div className="mt-5">
        <Field label="البيان">
          <textarea
            rows={2}
            value={form.description}
            onChange={(e) => set("description", e.target.value)}
            className={inputClass}
          />
        </Field>
      </div>

      {/* ربط دفعة عقد — يظهر حين يكون القيد على حساب أجور المقاولين */}
      {derived.debitCode === CONTRACTOR_EXPENSE && (
        <div className="mt-5 rounded-xl border border-blue-200 bg-blue-50 p-4">
          <p className="mb-3 text-sm font-bold">ربط الدفعة بعقد مقاول</p>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Field label="العقد" hint="اختياري — الربط يُحدّث المدفوع والمتبقي">
              <select
                value={form.contractNumber}
                onChange={(e) => {
                  setForm((prev) => ({
                    ...prev,
                    contractNumber: e.target.value,
                    installmentNumber: "",
                  }));
                }}
                className={inputClass}
              >
                <option value="">بدون ربط</option>
                {contractors
                  .filter((c) => !form.project || c.project === form.project)
                  .map((c) => (
                    <option key={c.id} value={c.contractNumber}>
                      {c.contractNumber} — {c.name} ({c.project})
                    </option>
                  ))}
              </select>
            </Field>

            {form.contractNumber && (
              <Field label="الدفعة">
                <select
                  value={form.installmentNumber}
                  onChange={(e) => set("installmentNumber", e.target.value)}
                  className={inputClass}
                >
                  <option value="">دفعة غير محدّدة</option>
                  {contractors
                    .find((c) => c.contractNumber === form.contractNumber)
                    ?.installments.map((i) => (
                      <option key={i.number} value={i.number}>
                        الدفعة {i.number} — {fmt(Number(i.value) || 0)} د.ك
                        {i.condition ? ` · ${i.condition}` : ""}
                      </option>
                    ))}
                </select>
              </Field>
            )}
          </div>
        </div>
      )}

      <label className="mt-5 flex items-center gap-2 text-sm font-medium">
        <input
          type="checkbox"
          checked={form.manual}
          onChange={(e) => set("manual", e.target.checked)}
        />
        تحديد طرفَي القيد يدوياً (للقيود التي لا تتبع البند وطريقة الدفع)
      </label>

      {form.manual && (
        <div className="mt-4 grid grid-cols-1 gap-5 md:grid-cols-2">
          {(
            [
              ["debitCode", "الحساب المدين"],
              ["creditCode", "الحساب الدائن"],
            ] as const
          ).map(([key, label]) => (
            <Field key={key} label={label}>
              <select
                value={form[key]}
                onChange={(e) => set(key, e.target.value)}
                className={inputClass}
              >
                <option value="">اختر الحساب</option>
                {POSTABLE_ACCOUNTS.map((a) => (
                  <option key={a.code} value={a.code}>
                    {a.code} — {a.name}
                  </option>
                ))}
              </select>
            </Field>
          ))}
        </div>
      )}

      <div className="mt-6 rounded-xl border border-slate-200 bg-slate-50 p-4">
        <p className="mb-3 text-sm font-bold">معاينة القيد</p>
        {check.valid ? (
          <table className="w-full text-sm">
            <tbody>
              <tr>
                <Td>من حـ/</Td>
                <Td>{accountLabel(derived.debitCode)}</Td>
                <Td className="text-left">
                  <Money value={round3(Number(form.amount))} bold />
                </Td>
              </tr>
              <tr>
                <Td>إلى حـ/</Td>
                <Td>{accountLabel(derived.creditCode)}</Td>
                <Td className="text-left">
                  <Money value={round3(Number(form.amount))} bold />
                </Td>
              </tr>
            </tbody>
          </table>
        ) : (
          <p className="text-sm text-amber-800">{check.problem}</p>
        )}
        {yearMismatch && (
          <p className="mt-2 text-sm text-amber-800">
            التاريخ يقع في السنة المالية {entryYear} بينما المعروض {year} — ستُحفظ
            في {entryYear}.
          </p>
        )}
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          onClick={handleSave}
          disabled={!check.valid}
          className="rounded-lg bg-slate-900 px-6 py-3 font-medium text-white disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {editing ? "حفظ التعديل" : "حفظ الحركة"}
        </button>

        {editing && (
          <button
            onClick={onCancelEdit}
            className="rounded-lg bg-slate-200 px-6 py-3 font-medium"
          >
            إلغاء التعديل
          </button>
        )}
      </div>

      {message && (
        <p className="mt-3 text-sm font-medium text-green-700">{message}</p>
      )}
    </Panel>
  );
}

/* ================================================================== */
/* جدول الحركات                                                        */
/* ================================================================== */

function MovementsTable({
  movements,
  onEdit,
  onVoucher,
  onDelete,
}: {
  movements: Movement[];
  onEdit: (movement: Movement) => void;
  onVoucher: (movement: Movement) => void;
  onDelete: (id: string) => void;
}) {
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return movements;
    return movements.filter((m) =>
      [m.description, m.party, m.itemName, m.project, m.person, m.debitCode, m.creditCode]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [movements, search]);

  const total = round3(filtered.reduce((acc, m) => acc + m.amount, 0));

  return (
    <Panel title="جدول الحركات">
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="بحث في البيان / الطرف / البند / المشروع / رقم الحساب…"
        className={`${inputClass} mb-5`}
      />

      {filtered.length === 0 ? (
        <Empty>لا توجد حركات مطابقة</Empty>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            {/* ترويسة ثابتة: الجدول قد يتجاوز ٦٠٠ صفاً */}
            <thead className="sticky top-0 z-10 bg-slate-100 shadow-sm">
              <tr>
                <Th>القيد</Th>
                <Th>التاريخ</Th>
                <Th>النوع</Th>
                <Th>البيان</Th>
                <Th>البند</Th>
                <Th>مدين</Th>
                <Th>دائن</Th>
                <Th>المبلغ</Th>
                <Th>المشروع</Th>
                <Th>الطريقة</Th>
                <Th>الحالة</Th>
                <Th>الإجراء</Th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((m) => {
                const check = validate(m);
                return (
                  <tr key={m.id} className="border-b border-slate-200">
                    <Td>{m.entryNo || "—"}</Td>
                    <Td>{m.date || "—"}</Td>
                    <Td>{m.movementType}</Td>
                    <Td>{m.description || "—"}</Td>
                    <Td>{m.itemName || "—"}</Td>
                    <Td>{m.debitCode || "—"}</Td>
                    <Td>{m.creditCode || "—"}</Td>
                    <Td>
                      <Money value={m.amount} />
                    </Td>
                    <Td>{m.project || "—"}</Td>
                    <Td>{m.paymentMethod || "—"}</Td>
                    <Td>
                      {check.valid ? (
                        <span className="text-green-700">سليم</span>
                      ) : (
                        <span className="text-red-600">{check.problem}</span>
                      )}
                    </Td>
                    <Td>
                      <div className="flex gap-2">
                        <button
                          onClick={() => onVoucher(m)}
                          disabled={!check.valid}
                          title="طباعة سند صرف أو قبض"
                          className="rounded-lg bg-slate-100 px-3 py-2 disabled:opacity-40"
                        >
                          🖨 سند
                        </button>
                        <button
                          onClick={() => onEdit(m)}
                          className="rounded-lg bg-blue-50 px-3 py-2 text-blue-700"
                        >
                          تعديل
                        </button>
                        <button
                          onClick={() => {
                            if (
                              window.confirm(
                                `حذف القيد ${m.entryNo} «${m.description}» بمبلغ ${fmt(m.amount)} د.ك؟`
                              )
                            ) {
                              onDelete(m.id);
                            }
                          }}
                          className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                        >
                          حذف
                        </button>
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-100 font-bold">
              <tr>
                <Td colSpan={7}>الإجمالي ({filtered.length} حركة)</Td>
                <Td>
                  <Money value={total} bold />
                </Td>
                <Td colSpan={4}>{""}</Td>
              </tr>
            </tfoot>
          </table>
        </div>
      )}
    </Panel>
  );
}

/* ================================================================== */
/* القيود اليومية                                                      */
/* ================================================================== */

function JournalPage({ movements }: { movements: Movement[] }) {
  if (movements.length === 0) {
    return (
      <Panel title="القيود اليومية">
        <Empty>لا توجد قيود في هذه السنة</Empty>
      </Panel>
    );
  }

  return (
    <Panel title="القيود اليومية" subtitle="مرتبة بالتاريخ ثم برقم القيد">
      <div className="overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead className="sticky top-0 z-10 bg-slate-100 shadow-sm">
            <tr>
              <Th>رقم القيد</Th>
              <Th>التاريخ</Th>
              <Th>البيان</Th>
              <Th>رقم الحساب</Th>
              <Th>الحساب</Th>
              <Th>مدين</Th>
              <Th>دائن</Th>
            </tr>
          </thead>
          <tbody>
            {movements.map((m) => {
              const check = validate(m);
              if (!check.valid) {
                return (
                  <tr key={m.id} className="border-b bg-red-50">
                    <Td>{m.entryNo}</Td>
                    <Td>{m.date || "—"}</Td>
                    <Td colSpan={5} className="text-red-700">
                      {m.description} — قيد غير صالح: {check.problem}
                    </Td>
                  </tr>
                );
              }
              return (
                <Fragment key={m.id}>
                  <tr className="border-b border-slate-100">
                    <Td>{m.entryNo}</Td>
                    <Td>{m.date}</Td>
                    <Td>{m.description || "—"}</Td>
                    <Td>{m.debitCode}</Td>
                    <Td>{getAccount(m.debitCode)?.name}</Td>
                    <Td>
                      <Money value={m.amount} />
                    </Td>
                    <Td>—</Td>
                  </tr>
                  <tr className="border-b-2 border-slate-200">
                    <Td>{""}</Td>
                    <Td>{""}</Td>
                    <Td>{""}</Td>
                    <Td>{m.creditCode}</Td>
                    <Td className="pr-8">{getAccount(m.creditCode)?.name}</Td>
                    <Td>—</Td>
                    <Td>
                      <Money value={m.amount} />
                    </Td>
                  </tr>
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}

/* ================================================================== */
/* دفتر الأستاذ                                                        */
/* ================================================================== */

function LedgerPage({
  movements,
  totals,
}: {
  movements: Movement[];
  totals: ReturnType<typeof computeTotals>;
}) {
  const [code, setCode] = useState("");

  const ledger = useMemo(
    () => (code ? buildLedger(movements, code, totals) : null),
    [movements, code, totals]
  );

  const sumDebit = ledger
    ? round3(ledger.lines.reduce((acc, l) => acc + l.debit, 0))
    : 0;
  const sumCredit = ledger
    ? round3(ledger.lines.reduce((acc, l) => acc + l.credit, 0))
    : 0;

  const show = (v: number) =>
    isZero(v) ? "—" : `${fmt(Math.abs(v))} ${v > 0 ? "مدين" : "دائن"}`;

  return (
    <Panel title="دفتر الأستاذ">
      <Field label="اختر الحساب">
        <select
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className={inputClass}
        >
          <option value="">اختر الحساب</option>
          {POSTABLE_ACCOUNTS.map((a) => (
            <option key={a.code} value={a.code}>
              {a.code} — {a.name}
            </option>
          ))}
        </select>
      </Field>

      {ledger && (
        <div className="mt-6 overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <Th>التاريخ</Th>
                <Th>القيد</Th>
                <Th>البيان</Th>
                <Th>الحساب المقابل</Th>
                <Th>مدين</Th>
                <Th>دائن</Th>
                <Th>الرصيد</Th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b bg-slate-50 font-medium">
                <Td colSpan={6}>الرصيد الافتتاحي</Td>
                <Td>{show(ledger.opening)}</Td>
              </tr>
              {ledger.lines.map((line, index) => (
                <tr key={index} className="border-b border-slate-200">
                  <Td>{line.date || "—"}</Td>
                  <Td>{line.entryNo}</Td>
                  <Td>{line.description || "—"}</Td>
                  <Td>{line.counterpart}</Td>
                  <Td>{line.debit ? <Money value={line.debit} /> : "—"}</Td>
                  <Td>{line.credit ? <Money value={line.credit} /> : "—"}</Td>
                  <Td>{show(line.balance)}</Td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-100 font-bold">
              <tr>
                <Td colSpan={4}>الإجمالي</Td>
                <Td>
                  <Money value={sumDebit} bold />
                </Td>
                <Td>
                  <Money value={sumCredit} bold />
                </Td>
                <Td>{show(ledger.closing)}</Td>
              </tr>
            </tfoot>
          </table>
          {ledger.lines.length === 0 && (
            <Empty>لا توجد حركات على هذا الحساب في هذه السنة</Empty>
          )}
        </div>
      )}
    </Panel>
  );
}

/* ================================================================== */
/* ميزان المراجعة                                                      */
/* ================================================================== */

function TrialBalancePage({
  report,
  year,
}: {
  report: ReturnType<typeof buildTrialBalance>;
  year: number;
}) {
  const cell = (v: number) => (isZero(v) ? "—" : fmt(v));

  return (
    <Panel
      title={`ميزان المراجعة ${year}`}
      subtitle={`${report.rows.length} حساباً به حركة أو رصيد`}
    >
      <div className="overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead className="bg-slate-100">
            <tr>
              <Th>رقم الحساب</Th>
              <Th>اسم الحساب</Th>
              <Th>افتتاحي مدين</Th>
              <Th>افتتاحي دائن</Th>
              <Th>حركة مدين</Th>
              <Th>حركة دائن</Th>
              <Th>ختامي مدين</Th>
              <Th>ختامي دائن</Th>
            </tr>
          </thead>
          <tbody>
            {report.rows.map((row) => (
              <tr key={row.account.code} className="border-b border-slate-200">
                <Td>{row.account.code}</Td>
                <Td>{row.account.name}</Td>
                <Td>{cell(row.openingDebit)}</Td>
                <Td>{cell(row.openingCredit)}</Td>
                <Td>{cell(row.periodDebit)}</Td>
                <Td>{cell(row.periodCredit)}</Td>
                <Td>{cell(row.closingDebit)}</Td>
                <Td>{cell(row.closingCredit)}</Td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-slate-100 font-bold">
            <tr>
              <Td colSpan={2}>الإجمالي</Td>
              <Td>{fmt(report.totals.openingDebit)}</Td>
              <Td>{fmt(report.totals.openingCredit)}</Td>
              <Td>{fmt(report.totals.periodDebit)}</Td>
              <Td>{fmt(report.totals.periodCredit)}</Td>
              <Td>{fmt(report.totals.closingDebit)}</Td>
              <Td>{fmt(report.totals.closingCredit)}</Td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="mt-4">
        {report.balanced ? (
          <Banner tone="ok">✓ الميزان متوازن في الأعمدة الثلاثة</Banner>
        ) : (
          <Banner tone="error">
            ⚠ غير متوازن — فرق الأرصدة الختامية{" "}
            {fmt(report.totals.closingDebit - report.totals.closingCredit)} د.ك
          </Banner>
        )}
      </div>
    </Panel>
  );
}

/* ================================================================== */
/* القوائم المالية                                                     */
/* ================================================================== */

function RowsTable({
  rows,
  label,
}: {
  rows: { code: string; name: string; amount: number }[];
  label: string;
}) {
  const visible = rows.filter((r) => !isZero(r.amount));
  if (visible.length === 0) {
    return <p className="px-4 py-3 text-sm text-slate-500">لا توجد أرصدة</p>;
  }
  return (
    <table className="w-full text-right text-sm">
      <thead className="bg-slate-50">
        <tr>
          <Th>رقم الحساب</Th>
          <Th>اسم الحساب</Th>
          <Th>{label}</Th>
        </tr>
      </thead>
      <tbody>
        {visible.map((row) => (
          <tr key={row.code} className="border-b border-slate-100">
            <Td>{row.code}</Td>
            <Td>{row.name}</Td>
            <Td>
              <Money value={row.amount} />
            </Td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function TotalLine({
  label,
  value,
  strong,
}: {
  label: string;
  value: number;
  strong?: boolean;
}) {
  return (
    <div
      className={`flex justify-between rounded-lg px-4 py-3 ${
        strong ? "bg-slate-200 font-bold" : "bg-slate-100 font-medium"
      }`}
    >
      <span>{label}</span>
      <Money value={value} bold={strong} />
    </div>
  );
}

function FinancialsPage({
  income,
  balanceSheet,
  cashFlow,
  cashByAccounts,
  equity,
}: {
  income: ReturnType<typeof buildIncomeStatement>;
  balanceSheet: ReturnType<typeof buildBalanceSheet>;
  cashFlow: ReturnType<typeof buildCashFlow>;
  cashByAccounts: number;
  equity: ReturnType<typeof buildEquityStatement>;
}) {
  const reconciles = nearlyEqual(cashFlow.closingCash, cashByAccounts);

  return (
    <>
      <Panel title="قائمة الدخل">
        <div className="space-y-2">
          <div className="rounded-lg bg-slate-100 px-4 py-3 font-bold">الإيرادات</div>
          <RowsTable rows={income.revenues} label="الإيرادات" />
          <TotalLine label="إجمالي الإيرادات" value={income.totalRevenue} />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            تكاليف المشاريع
          </div>
          <RowsTable rows={income.projectCosts} label="التكلفة" />
          <TotalLine
            label="إجمالي تكاليف المشاريع"
            value={income.totalProjectCosts}
          />
          <TotalLine
            label={income.grossProfit >= 0 ? "مجمل الربح" : "مجمل الخسارة"}
            value={income.grossProfit}
            strong
          />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            المصروفات الإدارية والعمومية
          </div>
          <RowsTable rows={income.adminExpenses} label="المصروف" />
          <TotalLine
            label="إجمالي المصروفات الإدارية والعمومية"
            value={income.totalAdminExpenses}
          />
          <TotalLine
            label={income.netProfit >= 0 ? "صافي الربح" : "صافي الخسارة"}
            value={income.netProfit}
            strong
          />
        </div>
      </Panel>

      <Panel title="قائمة المركز المالي">
        <div className="space-y-2">
          <div className="rounded-lg bg-slate-100 px-4 py-3 font-bold">الأصول</div>
          <RowsTable rows={balanceSheet.assets} label="الرصيد" />
          <TotalLine label="إجمالي الأصول" value={balanceSheet.totalAssets} strong />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            الخصوم
          </div>
          <RowsTable rows={balanceSheet.liabilities} label="الرصيد" />
          <TotalLine label="إجمالي الخصوم" value={balanceSheet.totalLiabilities} />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            حقوق الملكية
          </div>
          <RowsTable rows={balanceSheet.equityAccounts} label="الرصيد" />
          <div className="flex justify-between border-b border-slate-100 px-4 py-3">
            <span>صافي ربح / خسارة الفترة</span>
            <Money value={balanceSheet.netProfit} />
          </div>
          <TotalLine label="إجمالي حقوق الملكية" value={balanceSheet.totalEquity} />
          <TotalLine
            label="إجمالي الخصوم وحقوق الملكية"
            value={balanceSheet.totalLiabilitiesAndEquity}
            strong
          />
        </div>

        <div className="mt-4">
          {balanceSheet.balanced ? (
            <Banner tone="ok">✓ الميزانية متوازنة</Banner>
          ) : (
            <Banner tone="error">
              ⚠ غير متوازنة — الفرق {fmt(balanceSheet.difference)} د.ك
            </Banner>
          )}
        </div>
      </Panel>

      <Panel
        title="قائمة التغيرات في حقوق الملكية"
        subtitle="رصيد أول المدة + حركة الفترة + صافي النتيجة = رصيد آخر المدة"
      >
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <Th>رقم الحساب</Th>
                <Th>البند</Th>
                <Th>رصيد أول المدة</Th>
                <Th>حركة الفترة</Th>
                <Th>رصيد آخر المدة</Th>
              </tr>
            </thead>
            <tbody>
              {equity.rows.map((row) => (
                <tr key={row.code} className="border-b border-slate-100">
                  <Td>{row.code}</Td>
                  <Td>{row.name}</Td>
                  <Td>
                    <Money value={row.opening} />
                  </Td>
                  <Td>
                    <Money value={row.movement} />
                  </Td>
                  <Td>
                    <Money value={row.closing} />
                  </Td>
                </tr>
              ))}
              <tr className="border-b border-slate-100">
                <Td>—</Td>
                <Td>
                  {equity.netProfit >= 0
                    ? "صافي ربح الفترة"
                    : "صافي خسارة الفترة"}
                </Td>
                <Td>—</Td>
                <Td>
                  <Money value={equity.netProfit} />
                </Td>
                <Td>
                  <Money value={equity.netProfit} />
                </Td>
              </tr>
            </tbody>
            <tfoot className="bg-slate-200 font-bold">
              <tr>
                <Td colSpan={2}>إجمالي حقوق الملكية</Td>
                <Td>
                  <Money value={equity.openingTotal} bold />
                </Td>
                <Td>
                  <Money value={round3(equity.movementTotal + equity.netProfit)} bold />
                </Td>
                <Td>
                  <Money value={equity.closingTotal} bold />
                </Td>
              </tr>
            </tfoot>
          </table>
        </div>

        <div className="mt-4">
          {nearlyEqual(equity.closingTotal, balanceSheet.totalEquity) ? (
            <Banner tone="ok">
              ✓ رصيد آخر المدة مطابق لحقوق الملكية في قائمة المركز المالي
            </Banner>
          ) : (
            <Banner tone="error">
              ⚠ فرق {fmt(equity.closingTotal - balanceSheet.totalEquity)} د.ك عن
              قائمة المركز المالي
            </Banner>
          )}
        </div>
      </Panel>

      <Panel
        title="قائمة التدفقات النقدية"
        subtitle="الطريقة المباشرة — تصنيف الحركات التي مسّت الصندوق أو البنك"
      >
        <div className="space-y-2">
          <div className="rounded-lg bg-slate-100 px-4 py-3 font-bold">
            الأنشطة التشغيلية
          </div>
          <RowsTable rows={cashFlow.operating.lines} label="التدفق" />
          <TotalLine label="صافي التشغيلية" value={cashFlow.operating.total} />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            الأنشطة الاستثمارية
          </div>
          <RowsTable rows={cashFlow.investing.lines} label="التدفق" />
          <TotalLine label="صافي الاستثمارية" value={cashFlow.investing.total} />

          <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
            الأنشطة التمويلية
          </div>
          <RowsTable rows={cashFlow.financing.lines} label="التدفق" />
          <TotalLine label="صافي التمويلية" value={cashFlow.financing.total} />

          <div className="mt-4">
            <TotalLine
              label="صافي الزيادة (النقص) في النقدية"
              value={cashFlow.netChange}
              strong
            />
          </div>
          <TotalLine label="النقدية أول الفترة" value={cashFlow.openingCash} />
          <TotalLine label="النقدية آخر الفترة" value={cashFlow.closingCash} strong />
        </div>

        <div className="mt-4">
          {reconciles ? (
            <Banner tone="ok">
              ✓ رصيد النقدية ({fmt(cashFlow.closingCash)}) مطابق لرصيد الصندوق
              والبنك في دفتر الأستاذ
            </Banner>
          ) : (
            <Banner tone="error">
              ⚠ فرق {fmt(cashFlow.closingCash - cashByAccounts)} د.ك
            </Banner>
          )}
        </div>
      </Panel>
    </>
  );
}

/* ================================================================== */
/* التقارير التحليلية                                                  */
/* ================================================================== */

const MONTH_NAMES = [
  "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
  "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر",
];

function ReportsPage({
  movements,
  allMovements,
  year,
  income,
}: {
  movements: Movement[];
  allMovements: Movement[];
  year: number;
  income: ReturnType<typeof buildIncomeStatement>;
}) {
  const monthly = useMemo(() => monthlyExpenses(movements, year), [movements, year]);
  const projects = useMemo(
    () => projectLifetimeAnalysis(allMovements, year),
    [allMovements, year]
  );

  const topExpenses = useMemo(
    () =>
      [...income.projectCosts, ...income.adminExpenses]
        .filter((r) => !isZero(r.amount))
        .sort((a, b) => b.amount - a.amount),
    [income]
  );
  const expenseTotal = round3(topExpenses.reduce((s, r) => s + r.amount, 0));

  // الأشهر التي بها حركة فعلية فقط، حتى لا يمتد الجدول بلا داع
  const activeMonths = monthly.months
    .map((_, i) => i)
    .filter((i) => !isZero(monthly.monthTotals[i]));

  return (
    <>
      <Panel
        title={`أكبر بنود الصرف ${year}`}
        subtitle={`${topExpenses.length} حساب · الإجمالي ${fmt(expenseTotal)} د.ك`}
      >
        {topExpenses.length === 0 ? (
          <Empty>لا توجد مصروفات</Empty>
        ) : (
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <Th>الحساب</Th>
                <Th>البند</Th>
                <Th>المبلغ</Th>
                <Th>النسبة</Th>
                <Th>{""}</Th>
              </tr>
            </thead>
            <tbody>
              {topExpenses.map((row) => {
                const share = expenseTotal > 0 ? (row.amount / expenseTotal) * 100 : 0;
                return (
                  <tr key={row.code} className="border-b border-slate-100">
                    <Td>{row.code}</Td>
                    <Td>{row.name}</Td>
                    <Td>
                      <Money value={row.amount} />
                    </Td>
                    <Td>{share.toFixed(1)}%</Td>
                    <Td>
                      <div className="h-2 w-40 overflow-hidden rounded-full bg-slate-200">
                        <div
                          className="h-full bg-blue-600"
                          style={{ width: `${Math.min(share, 100)}%` }}
                        />
                      </div>
                    </Td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="bg-slate-100 font-bold">
              <tr>
                <Td colSpan={2}>الإجمالي</Td>
                <Td>
                  <Money value={expenseTotal} bold />
                </Td>
                <Td colSpan={2}>100%</Td>
              </tr>
            </tfoot>
          </table>
        )}
      </Panel>

      <Panel
        title="تحليل المشاريع — منذ بداية كل مشروع"
        subtitle="ربحية المشروع تُقاس على عمره كله، لا على سنة مالية واحدة"
      >
        {projects.multiYear > 0 && (
          <Banner tone="warn">
            <b>{projects.multiYear}</b> مشروع ممتد عبر أكثر من سنة مالية. النتيجة
            المعتمدة هي <b>الإجمالي التراكمي</b> — أما أعمدة «{year}» فتبيّن مساهمة
            هذه السنة وحدها، وقد تظهر سالبة لمشروع رابح قُبض إيراده في سنة سابقة.
          </Banner>
        )}

        {projects.rows.length === 0 ? (
          <Empty>لا توجد حركات مرتبطة بمشاريع</Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead>
                <tr className="bg-slate-200">
                  <th className="px-4 py-2 text-right" colSpan={3}>
                    {""}
                  </th>
                  <th className="px-4 py-2 text-center font-bold" colSpan={3}>
                    منذ البداية (المعتمد)
                  </th>
                  <th className="px-4 py-2 text-center font-bold" colSpan={3}>
                    مساهمة {year}
                  </th>
                  <th className="px-4 py-2">{""}</th>
                </tr>
                <tr className="bg-slate-100">
                  <Th>المشروع</Th>
                  <Th>السنوات</Th>
                  <Th>الحركات</Th>
                  <Th>الإيرادات</Th>
                  <Th>التكاليف</Th>
                  <Th>النتيجة</Th>
                  <Th>الإيرادات</Th>
                  <Th>التكاليف</Th>
                  <Th>النتيجة</Th>
                  <Th>نصيبه</Th>
                </tr>
              </thead>
              <tbody>
                {projects.rows.map((row) => {
                  const tone = (n: number) =>
                    n > 0
                      ? "font-bold text-green-700"
                      : n < 0
                      ? "font-bold text-red-600"
                      : "";
                  return (
                    <tr key={row.project} className="border-b border-slate-100">
                      <Td>{row.project}</Td>
                      <Td className="whitespace-nowrap">{row.years.join("، ")}</Td>
                      <Td>{row.movements}</Td>
                      <Td>
                        <Money value={row.lifetime.revenue} />
                      </Td>
                      <Td>
                        <Money value={row.lifetime.cost} />
                      </Td>
                      <Td className={tone(row.lifetime.net)}>
                        {fmt(row.lifetime.net)}
                      </Td>
                      <Td className="text-slate-500">
                        {fmt(row.inYear.revenue)}
                      </Td>
                      <Td className="text-slate-500">{fmt(row.inYear.cost)}</Td>
                      <Td className="text-slate-500">{fmt(row.inYear.net)}</Td>
                      <Td>{row.costShare.toFixed(1)}%</Td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-100 font-bold">
                <tr>
                  <Td colSpan={3}>الإجمالي</Td>
                  <Td>
                    <Money value={projects.lifetime.revenue} bold />
                  </Td>
                  <Td>
                    <Money value={projects.lifetime.cost} bold />
                  </Td>
                  <Td>
                    <Money value={projects.lifetime.net} bold />
                  </Td>
                  <Td>{fmt(projects.inYear.revenue)}</Td>
                  <Td>{fmt(projects.inYear.cost)}</Td>
                  <Td>{fmt(projects.inYear.net)}</Td>
                  <Td>100%</Td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </Panel>

      <Panel
        title={`المصروفات الشهرية ${year}`}
        subtitle="كل بند صرف موزّعاً على أشهر السنة"
      >
        {monthly.rows.length === 0 ? (
          <Empty>لا توجد مصروفات في هذه السنة</Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-100">
                <tr>
                  <Th>البند</Th>
                  {activeMonths.map((m) => (
                    <Th key={m}>{MONTH_NAMES[m]}</Th>
                  ))}
                  <Th>الإجمالي</Th>
                </tr>
              </thead>
              <tbody>
                {monthly.rows.map((row) => (
                  <tr key={row.code} className="border-b border-slate-100">
                    <Td className="whitespace-nowrap">
                      {row.code} — {row.name}
                    </Td>
                    {activeMonths.map((m) => (
                      <Td key={m}>
                        {isZero(row.byMonth[m]) ? (
                          <span className="text-slate-300">—</span>
                        ) : (
                          fmt(row.byMonth[m])
                        )}
                      </Td>
                    ))}
                    <Td className="font-bold">{fmt(row.total)}</Td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold">
                <tr>
                  <Td>إجمالي الشهر</Td>
                  {activeMonths.map((m) => (
                    <Td key={m}>{fmt(monthly.monthTotals[m])}</Td>
                  ))}
                  <Td>{fmt(monthly.grandTotal)}</Td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </Panel>
    </>
  );
}

/* ================================================================== */
/* المشاريع                                                            */
/* ================================================================== */

function ProjectsPage({
  projects,
  movements,
  year,
  setProjects,
  openProject,
}: {
  projects: Project[];
  /** كل الحركات في كل السنوات — ميزانية المشروع تُقاس على عمره لا على سنة */
  movements: Movement[];
  year: number;
  setProjects: Dispatch<SetStateAction<Project[]>>;
  openProject: (project: Project) => void;
}) {
  const [name, setName] = useState("");
  const [budget, setBudget] = useState("");
  const [error, setError] = useState("");

  const add = () => {
    const trimmed = name.trim();
    if (!trimmed) return setError("اسم المشروع مطلوب");
    if (projects.some((p) => p.name === trimmed)) {
      return setError("يوجد مشروع بنفس الاسم — الحركات تُربط بالاسم");
    }
    setProjects((prev) => [
      ...prev,
      { id: newId(), name: trimmed, budget: round3(Number(budget) || 0), status: "نشط" },
    ]);
    setName("");
    setBudget("");
    setError("");
  };

  return (
    <Panel
      title="المشاريع"
      subtitle="الأرقام تراكمية منذ بداية كل مشروع — الميزانية تُستهلك عبر السنوات لا داخل سنة واحدة"
    >
      <div className="flex flex-wrap gap-3">
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="اسم المشروع"
          className={`${inputClass} flex-1`}
        />
        <input
          type="number"
          step="0.001"
          value={budget}
          onChange={(e) => setBudget(e.target.value)}
          placeholder="ميزانية المشروع"
          className={`${inputClass} flex-1`}
        />
        <button
          onClick={add}
          className="rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
        >
          إضافة مشروع
        </button>
      </div>
      {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

      {projects.length === 0 ? (
        <Empty>لا توجد مشاريع</Empty>
      ) : (
        <div className="mt-6 space-y-3">
          {projects.map((project) => {
            const s = projectSummary(movements, project.name);
            const mine = movements.filter((m) => m.project === project.name);
            const count = mine.length;
            const years = [...new Set(mine.map((m) => m.fiscalYear))].sort();
            const inYear = projectSummary(
              movements.filter((m) => m.fiscalYear === year),
              project.name
            );
            const usage = project.budget > 0 ? (s.cost / project.budget) * 100 : 0;

            return (
              <div key={project.id} className="rounded-xl border border-slate-200 p-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <button
                    onClick={() => openProject(project)}
                    className="text-lg font-bold text-blue-700 hover:underline"
                  >
                    {project.name}
                  </button>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-slate-500">
                      {count} حركة · {years.join("، ")}
                    </span>
                    <button
                      onClick={() => {
                        if (window.confirm(`حذف المشروع «${project.name}»؟`)) {
                          setProjects((prev) =>
                            prev.filter((p) => p.id !== project.id)
                          );
                        }
                      }}
                      className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                    >
                      حذف
                    </button>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-3 text-sm md:grid-cols-5">
                  {[
                    ["الميزانية", project.budget],
                    ["الإيرادات (تراكمي)", s.revenue],
                    ["التكاليف (تراكمي)", s.cost],
                    ["المتبقي من الميزانية", round3(project.budget - s.cost)],
                    ["صافي النتيجة (تراكمي)", s.net],
                  ].map(([label, value]) => (
                    <div key={String(label)}>
                      <p className="text-slate-500">{label}</p>
                      <p className="font-bold">
                        <Money value={value as number} />
                      </p>
                    </div>
                  ))}
                </div>

                {years.length > 1 && (
                  <p className="mt-2 text-xs text-slate-500">
                    مساهمة {year} وحدها: إيرادات {fmt(inYear.revenue)} · تكاليف{" "}
                    {fmt(inYear.cost)} · النتيجة {fmt(inYear.net)}
                  </p>
                )}

                {project.budget > 0 && (
                  <div className="mt-3">
                    <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
                      <div
                        className={`h-full ${
                          usage >= 100
                            ? "bg-red-600"
                            : usage >= 80
                            ? "bg-orange-500"
                            : "bg-blue-600"
                        }`}
                        style={{ width: `${Math.min(usage, 100)}%` }}
                      />
                    </div>
                    <p className="mt-1 text-xs text-slate-500">
                      استهلاك الميزانية: {usage.toFixed(1)}%
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Panel>
  );
}

/* ================================================================== */
/* حركات المشروع                                                       */
/* ================================================================== */

function ProjectMovementsPage({
  projectName,
  movements,
  year,
  onBack,
}: {
  projectName: string;
  movements: Movement[];
  year: number;
  onBack: () => void;
}) {
  const [typeFilter, setTypeFilter] = useState("الكل");
  const [itemFilter, setItemFilter] = useState("الكل");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [search, setSearch] = useState("");
  /** المشروع يمتد عبر السنوات، فالنطاق الافتراضي عمره كله */
  const [scope, setScope] = useState<"lifetime" | "year">("lifetime");

  const projectMovements = useMemo(
    () =>
      movements.filter(
        (m) =>
          m.project === projectName &&
          (scope === "lifetime" || m.fiscalYear === year)
      ),
    [movements, projectName, scope, year]
  );

  // فلترة واحدة تُستخدم في البطاقات والجدول والإجمالي معاً
  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return projectMovements.filter((m) => {
      if (typeFilter !== "الكل" && m.movementType !== typeFilter) return false;
      if (itemFilter !== "الكل" && m.itemName !== itemFilter) return false;
      if (from && m.date < from) return false;
      if (to && m.date > to) return false;
      if (q && !(m.description || "").toLowerCase().includes(q)) return false;
      return true;
    });
  }, [projectMovements, typeFilter, itemFilter, from, to, search]);

  const summary = useMemo(() => {
    let revenue = 0;
    let cost = 0;
    for (const m of filtered) {
      if (!validate(m).valid) continue;
      if (getAccount(m.creditCode)?.type === "إيرادات") revenue += m.amount;
      if (getAccount(m.debitCode)?.type === "مصروفات") cost += m.amount;
    }
    revenue = round3(revenue);
    cost = round3(cost);
    return { revenue, cost, net: round3(revenue - cost) };
  }, [filtered]);

  const items = useMemo(
    () => [...new Set(projectMovements.map((m) => m.itemName).filter(Boolean))],
    [projectMovements]
  );
  const types = useMemo(
    () => [...new Set(projectMovements.map((m) => m.movementType).filter(Boolean))],
    [projectMovements]
  );

  return (
    <Panel title="حركات المشروع" subtitle={projectName}>
      <div className="mb-5 flex gap-3">
        <button onClick={onBack} className="rounded-lg bg-slate-200 px-4 py-2 font-bold">
          العودة للمشاريع
        </button>
        <button
          onClick={() => {
            setTypeFilter("الكل");
            setItemFilter("الكل");
            setFrom("");
            setTo("");
            setSearch("");
          }}
          className="rounded-lg bg-slate-200 px-4 py-2 font-bold"
        >
          مسح الفلاتر
        </button>

        <div className="flex overflow-hidden rounded-lg border border-slate-300">
          {(
            [
              ["lifetime", "كل عمر المشروع"],
              ["year", `سنة ${year} فقط`],
            ] as const
          ).map(([value, label]) => (
            <button
              key={value}
              onClick={() => setScope(value)}
              className={`px-4 py-2 font-bold ${
                scope === value ? "bg-blue-600 text-white" : "bg-white"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        {[
          ["إجمالي الإيرادات", summary.revenue],
          ["إجمالي التكاليف", summary.cost],
          ["صافي المشروع", summary.net],
        ].map(([label, value]) => (
          <div
            key={String(label)}
            className="rounded-xl border border-slate-200 bg-slate-50 p-5 text-center"
          >
            <p className="text-sm text-slate-500">{label}</p>
            <p className="mt-2 text-xl font-bold">
              <Money value={value as number} /> د.ك
            </p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
        <Field label="نوع الحركة">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className={inputClass}
          >
            <option value="الكل">جميع الحركات</option>
            {types.map((t) => (
              <option key={t}>{t}</option>
            ))}
          </select>
        </Field>
        <Field label="البند">
          <select
            value={itemFilter}
            onChange={(e) => setItemFilter(e.target.value)}
            className={inputClass}
          >
            <option value="الكل">جميع البنود</option>
            {items.map((i) => (
              <option key={i}>{i}</option>
            ))}
          </select>
        </Field>
        <Field label="من تاريخ">
          <input
            type="date"
            value={from}
            onChange={(e) => setFrom(e.target.value)}
            className={inputClass}
          />
        </Field>
        <Field label="إلى تاريخ">
          <input
            type="date"
            value={to}
            onChange={(e) => setTo(e.target.value)}
            className={inputClass}
          />
        </Field>
      </div>

      <div className="mt-4">
        <Field label="البحث في البيان">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="اكتب كلمة من البيان…"
            className={inputClass}
          />
        </Field>
      </div>

      <div className="mt-6 overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead className="bg-slate-100">
            <tr>
              <Th>التاريخ</Th>
              <Th>النوع</Th>
              <Th>البند</Th>
              <Th>البيان</Th>
              <Th>الطريقة</Th>
              <Th>المبلغ</Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => (
              <tr key={m.id} className="border-b border-slate-200">
                <Td>{m.date || "—"}</Td>
                <Td>{m.movementType}</Td>
                <Td>{m.itemName || "—"}</Td>
                <Td>{m.description || "—"}</Td>
                <Td>{m.paymentMethod || "—"}</Td>
                <Td>
                  <Money value={m.amount} />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <Empty>لا توجد حركات مطابقة للفلاتر</Empty>}
      </div>

      <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
        عدد الحركات الظاهرة: {filtered.length} | إجمالي المبالغ الظاهرة:{" "}
        <Money value={round3(filtered.reduce((a, m) => a + m.amount, 0))} bold /> د.ك
      </div>
    </Panel>
  );
}

/* ================================================================== */
/* المقاولون                                                           */
/* ================================================================== */

const INSTALLMENT_STATUSES = ["غير مستحقة", "مستحقة", "مدفوعة جزئياً", "مدفوعة"];

const BLANK_CONTRACT = {
  name: "",
  specialty: "",
  phone: "",
  project: "",
  contractNumber: "",
  contractType: "",
  workType: "",
  contractValue: "",
};

function ContractorsPage({
  contractors,
  projects,
  movements,
  setContractors,
  onLink,
}: {
  contractors: Contractor[];
  projects: Project[];
  movements: Movement[];
  setContractors: Dispatch<SetStateAction<Contractor[]>>;
  onLink: (
    movementId: string,
    contractNumber: string,
    installmentNumber: number | undefined
  ) => void;
}) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(BLANK_CONTRACT);
  const [installments, setInstallments] = useState<Installment[]>([]);
  const [error, setError] = useState("");
  const [linkInstallment, setLinkInstallment] = useState("");

  const selected = contractors.find((c) => c.id === selectedId) ?? null;

  const set = (key: keyof typeof BLANK_CONTRACT, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const installmentsTotal = round3(
    installments.reduce((a, i) => a + (Number(i.value) || 0), 0)
  );
  const contractValue = round3(Number(form.contractValue) || 0);

  const openNew = () => {
    setEditingId(null);
    setForm(BLANK_CONTRACT);
    setInstallments([]);
    setError("");
    setShowForm(true);
  };

  const openEdit = (c: Contractor) => {
    setEditingId(c.id);
    setForm({
      name: c.name,
      specialty: c.specialty,
      phone: c.phone,
      project: c.project,
      contractNumber: c.contractNumber,
      contractType: c.contractType,
      workType: c.workType,
      contractValue: String(c.contractValue),
    });
    setInstallments(c.installments.map((i) => ({ ...i })));
    setError("");
    setShowForm(true);
  };

  const setCount = (raw: string) => {
    const count = Math.max(0, Math.min(Number(raw) || 0, 60));
    setInstallments((prev) =>
      Array.from({ length: count }, (_, index) =>
        prev[index]
          ? { ...prev[index], number: index + 1 }
          : {
              number: index + 1,
              value: "",
              condition: "",
              status: "غير مستحقة",
              approved: false,
              approvedBy: "",
              approvedAt: "",
              approvalNote: "",
            }
      )
    );
  };

  const updateInstallment = (
    index: number,
    key: keyof Installment,
    value: string
  ) =>
    setInstallments((prev) =>
      prev.map((item, i) => (i === index ? { ...item, [key]: value } : item))
    );

  const save = () => {
    const checks: [boolean, string][] = [
      [!form.name.trim(), "اسم المقاول مطلوب"],
      [!form.contractNumber.trim(), "رقم العقد مطلوب"],
      [!form.project, "اختيار المشروع مطلوب"],
      [!form.workType.trim(), "نوع الأعمال مطلوب"],
      [contractValue <= 0, "قيمة العقد يجب أن تكون أكبر من صفر"],
      [installments.length === 0, "عدد الدفعات مطلوب"],
      [
        installments.some((i) => !i.value || Number(i.value) <= 0),
        "يجب إدخال قيمة كل دفعة",
      ],
      [
        contractors.some(
          (c) =>
            c.id !== editingId &&
            c.contractNumber.trim().toLowerCase() ===
              form.contractNumber.trim().toLowerCase()
        ),
        "رقم العقد مستخدم مسبقاً",
      ],
      [
        !nearlyEqual(installmentsTotal, contractValue),
        `مجموع الدفعات (${fmt(installmentsTotal)}) لا يساوي قيمة العقد (${fmt(contractValue)})`,
      ],
    ];

    const failed = checks.find(([bad]) => bad);
    if (failed) return setError(failed[1]);

    const record: Contractor = {
      id: editingId ?? newId(),
      name: form.name.trim(),
      specialty: form.specialty.trim(),
      phone: form.phone.trim(),
      project: form.project,
      contractNumber: form.contractNumber.trim(),
      contractType: form.contractType.trim(),
      workType: form.workType.trim(),
      contractValue,
      installmentsCount: installments.length,
      installments: installments.map((i) => ({ ...i })),
    };

    setContractors((prev) =>
      editingId ? prev.map((c) => (c.id === editingId ? record : c)) : [...prev, record]
    );
    setShowForm(false);
    setEditingId(null);
    setError("");
  };

  const payments = (c: Contractor) => contractPayments(movements, c.contractNumber);

  const candidates = selected
    ? unlinkedContractorMovements(movements, selected.project)
    : [];

  return (
    <>
      <Panel
        title="عقود المقاولين"
        subtitle={`${contractors.length} عقد — «المدفوع» محسوب من قيود الدفع المرتبطة`}
      >
        <button
          onClick={showForm ? () => setShowForm(false) : openNew}
          className="mb-5 rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
        >
          {showForm ? "إخفاء النموذج" : "إضافة عقد جديد"}
        </button>

        {showForm && (
          <div className="mb-6 rounded-xl border border-slate-200 p-5">
            <h4 className="mb-4 font-bold">
              {editingId ? "تعديل العقد" : "عقد جديد"}
            </h4>

            <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
              {(
                [
                  ["contractNumber", "رقم العقد"],
                  ["name", "اسم المقاول"],
                  ["workType", "نوع الأعمال"],
                  ["specialty", "التخصص"],
                  ["phone", "رقم الهاتف"],
                  ["contractType", "حالة العقد"],
                ] as [keyof typeof BLANK_CONTRACT, string][]
              ).map(([key, placeholder]) => (
                <input
                  key={key}
                  type="text"
                  value={form[key]}
                  onChange={(e) => set(key, e.target.value)}
                  placeholder={placeholder}
                  className={inputClass}
                />
              ))}

              <select
                value={form.project}
                onChange={(e) => set("project", e.target.value)}
                className={inputClass}
              >
                <option value="">اختر المشروع</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.name}>
                    {p.name}
                  </option>
                ))}
              </select>

              <input
                type="number"
                step="0.001"
                value={form.contractValue}
                onChange={(e) => set("contractValue", e.target.value)}
                placeholder="قيمة العقد"
                className={inputClass}
              />

              <input
                type="number"
                min="0"
                max="60"
                value={installments.length || ""}
                onChange={(e) => setCount(e.target.value)}
                placeholder="عدد الدفعات"
                className={inputClass}
              />
            </div>

            {installments.length > 0 && (
              <div className="mt-5 space-y-2">
                {installments.map((installment, index) => (
                  <div key={index} className="grid grid-cols-4 gap-3">
                    <div className="rounded-lg border border-slate-200 bg-slate-50 px-4 py-3">
                      الدفعة {index + 1}
                    </div>
                    <input
                      type="number"
                      step="0.001"
                      value={installment.value}
                      onChange={(e) => updateInstallment(index, "value", e.target.value)}
                      placeholder="القيمة"
                      className={inputClass}
                    />
                    <input
                      type="text"
                      value={installment.condition}
                      onChange={(e) =>
                        updateInstallment(index, "condition", e.target.value)
                      }
                      placeholder="الاستحقاق"
                      className={inputClass}
                    />
                    <select
                      value={installment.status}
                      onChange={(e) =>
                        updateInstallment(index, "status", e.target.value)
                      }
                      className={inputClass}
                    >
                      {INSTALLMENT_STATUSES.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                ))}

                <div
                  className={`rounded-lg border px-4 py-3 font-medium ${
                    nearlyEqual(installmentsTotal, contractValue)
                      ? "border-green-200 bg-green-50 text-green-800"
                      : "border-amber-200 bg-amber-50 text-amber-900"
                  }`}
                >
                  مجموع الدفعات {fmt(installmentsTotal)} — قيمة العقد {fmt(contractValue)}
                </div>
              </div>
            )}

            {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

            <div className="mt-5 flex gap-3">
              <button
                onClick={save}
                className="rounded-lg bg-slate-900 px-6 py-3 font-bold text-white"
              >
                {editingId ? "حفظ التعديل" : "حفظ العقد"}
              </button>
              <button
                onClick={() => setShowForm(false)}
                className="rounded-lg bg-slate-200 px-6 py-3 font-bold"
              >
                إلغاء
              </button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <Th>رقم العقد</Th>
                <Th>المقاول</Th>
                <Th>المشروع</Th>
                <Th>نوع الأعمال</Th>
                <Th>قيمة العقد</Th>
                <Th>المدفوع</Th>
                <Th>المتبقي</Th>
                <Th>الإجراء</Th>
              </tr>
            </thead>
            <tbody>
              {contractors.length === 0 ? (
                <tr>
                  <Td colSpan={8} className="text-center text-slate-500">
                    لا توجد عقود
                  </Td>
                </tr>
              ) : (
                contractors.map((c) => {
                  const paid = payments(c).total;
                  return (
                    <tr key={c.id} className="border-b border-slate-200">
                      <Td>
                        <button
                          onClick={() => setSelectedId(c.id)}
                          className="text-blue-600 underline"
                        >
                          {c.contractNumber}
                        </button>
                      </Td>
                      <Td>{c.name}</Td>
                      <Td>{c.project}</Td>
                      <Td>{c.workType}</Td>
                      <Td>
                        <Money value={c.contractValue} />
                      </Td>
                      <Td>
                        <Money value={paid} />
                      </Td>
                      <Td>
                        <Money value={round3(c.contractValue - paid)} />
                      </Td>
                      <Td>
                        <div className="flex gap-2">
                          <button
                            onClick={() => openEdit(c)}
                            className="rounded-lg bg-blue-50 px-3 py-2 text-blue-700"
                          >
                            تعديل
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`حذف عقد «${c.contractNumber}»؟`)) {
                                setContractors((prev) =>
                                  prev.filter((x) => x.id !== c.id)
                                );
                                if (selectedId === c.id) setSelectedId(null);
                              }
                            }}
                            className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                          >
                            حذف
                          </button>
                        </div>
                      </Td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Panel>

      {selected && (
        <Panel
          title={`عقد ${selected.contractNumber} — ${selected.name}`}
          subtitle={`${selected.project} · ${selected.workType}`}
        >
          <button
            onClick={() => setSelectedId(null)}
            className="mb-4 text-sm text-slate-500 hover:underline"
          >
            إغلاق التفاصيل
          </button>

          {(() => {
            const p = payments(selected);
            return (
              <>
                <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-3">
                  {[
                    ["قيمة العقد", selected.contractValue],
                    ["المدفوع", p.total],
                    ["المتبقي", round3(selected.contractValue - p.total)],
                  ].map(([label, value]) => (
                    <div
                      key={String(label)}
                      className="rounded-xl border border-slate-200 p-4"
                    >
                      <p className="text-sm text-slate-500">{label}</p>
                      <p className="mt-1 text-xl font-bold">
                        <Money value={value as number} /> د.ك
                      </p>
                    </div>
                  ))}
                </div>

                <table className="w-full text-right text-sm">
                  <thead className="bg-slate-100">
                    <tr>
                      <Th>#</Th>
                      <Th>الاستحقاق</Th>
                      <Th>القيمة</Th>
                      <Th>اعتماد الإنجاز</Th>
                      <Th>المدفوع فعلاً</Th>
                      <Th>المتبقي</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {selected.installments.map((i) => {
                      const value = round3(Number(i.value) || 0);
                      const paid = p.byInstallment.get(i.number) ?? 0;
                      return (
                        <tr key={i.number} className="border-b border-slate-100">
                          <Td>{i.number}</Td>
                          <Td>{i.condition || "—"}</Td>
                          <Td>
                            <Money value={value} />
                          </Td>
                          <Td>
                            {i.approved ? (
                              <span className="font-bold text-green-700">
                                ✓ معتمدة — مستحقة
                              </span>
                            ) : (
                              <span className="text-slate-400">لم تُعتمد</span>
                            )}
                          </Td>
                          <Td>
                            <Money value={paid} />
                          </Td>
                          <Td>
                            <Money value={round3(value - paid)} />
                          </Td>
                        </tr>
                      );
                    })}
                    {(p.byInstallment.get(0) ?? 0) !== 0 && (
                      <tr className="border-b border-slate-100 bg-amber-50">
                        <Td>—</Td>
                        <Td colSpan={2}>دفعات مرتبطة بالعقد بلا رقم دفعة</Td>
                        <Td>
                          <Money value={p.byInstallment.get(0) ?? 0} />
                        </Td>
                        <Td colSpan={2}>{""}</Td>
                      </tr>
                    )}
                  </tbody>
                </table>

                <h5 className="mb-3 mt-6 font-bold">
                  قيود الدفع المرتبطة ({p.movements.length})
                </h5>
                {p.movements.length === 0 ? (
                  <p className="text-sm text-slate-500">
                    لا توجد قيود مرتبطة بعد — اربطها من القائمة أدناه.
                  </p>
                ) : (
                  <table className="w-full text-right text-sm">
                    <thead className="bg-slate-50">
                      <tr>
                        <Th>القيد</Th>
                        <Th>التاريخ</Th>
                        <Th>البيان</Th>
                        <Th>الدفعة</Th>
                        <Th>المبلغ</Th>
                        <Th>فكّ الربط</Th>
                      </tr>
                    </thead>
                    <tbody>
                      {p.movements.map((m) => (
                        <tr key={m.id} className="border-b border-slate-100">
                          <Td>{m.entryNo}</Td>
                          <Td>{m.date}</Td>
                          <Td>{m.description || "—"}</Td>
                          <Td>{m.installmentNumber || "غير محدّدة"}</Td>
                          <Td>
                            <Money value={m.amount} />
                          </Td>
                          <Td>
                            <button
                              onClick={() => onLink(m.id, "", undefined)}
                              className="rounded-lg bg-slate-100 px-3 py-1"
                            >
                              فكّ
                            </button>
                          </Td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                <h5 className="mb-3 mt-6 font-bold">
                  حركات أجور مقاولين غير مرتبطة في {selected.project} ({candidates.length})
                </h5>
                {candidates.length === 0 ? (
                  <p className="text-sm text-slate-500">لا توجد حركات مرشّحة.</p>
                ) : (
                  <>
                    <div className="mb-3 max-w-sm">
                      <Field label="اربط بالدفعة رقم">
                        <select
                          value={linkInstallment}
                          onChange={(e) => setLinkInstallment(e.target.value)}
                          className={inputClass}
                        >
                          <option value="">دفعة غير محدّدة</option>
                          {selected.installments.map((i) => (
                            <option key={i.number} value={i.number}>
                              الدفعة {i.number} — {fmt(Number(i.value) || 0)} د.ك
                            </option>
                          ))}
                        </select>
                      </Field>
                    </div>

                    <table className="w-full text-right text-sm">
                      <thead className="bg-slate-50">
                        <tr>
                          <Th>القيد</Th>
                          <Th>التاريخ</Th>
                          <Th>البيان</Th>
                          <Th>المبلغ</Th>
                          <Th>ربط</Th>
                        </tr>
                      </thead>
                      <tbody>
                        {candidates.map((m) => (
                          <tr key={m.id} className="border-b border-slate-100">
                            <Td>{m.entryNo}</Td>
                            <Td>{m.date}</Td>
                            <Td>{m.description || "—"}</Td>
                            <Td>
                              <Money value={m.amount} />
                            </Td>
                            <Td>
                              <button
                                onClick={() =>
                                  onLink(
                                    m.id,
                                    selected.contractNumber,
                                    Number(linkInstallment) || undefined
                                  )
                                }
                                className="rounded-lg bg-blue-600 px-3 py-1 text-white"
                              >
                                ربط
                              </button>
                            </Td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </>
                )}
              </>
            );
          })()}
        </Panel>
      )}
    </>
  );
}

/* ================================================================== */
/* متابعة السلف والعهد                                                 */
/* ================================================================== */

function AdvancesPage({
  movements,
  year,
  onEdit,
}: {
  movements: Movement[];
  year: number;
  onEdit: (movement: Movement) => void;
}) {
  const [person, setPerson] = useState<string | null>(null);
  const report = useMemo(() => buildAdvances(movements), [movements]);
  const selected = report.rows.find((r) => r.person === person) ?? null;

  const verdict = (balance: number) =>
    isZero(balance)
      ? { text: "مسوّاة", cls: "text-slate-500" }
      : balance > 0
      ? { text: "بذمته للشركة", cls: "text-amber-700 font-bold" }
      : { text: "الشركة مدينة له", cls: "text-blue-700 font-bold" };

  return (
    <>
      <Panel
        title={`متابعة السلف والعهد ${year}`}
        subtitle="حـ/1140 عهد الموظفين · حـ/1240 سلف الموظفين — محسوبة من القيود مباشرة"
      >
        {report.rows.length === 0 ? (
          <Empty>لا توجد حركات سلف أو عهد في هذه السنة</Empty>
        ) : (
          <>
            <div className="mb-5 grid grid-cols-1 gap-3 md:grid-cols-3">
              {[
                ["إجمالي المسلَّم", report.totals.given],
                ["إجمالي المصروف والمسدَّد", report.totals.settled],
                ["صافي الأرصدة القائمة", report.totals.balance],
              ].map(([label, value]) => (
                <div
                  key={String(label)}
                  className="rounded-xl border border-slate-200 p-4"
                >
                  <p className="text-sm text-slate-500">{label}</p>
                  <p className="mt-1 text-xl font-bold">
                    <Money value={value as number} /> د.ك
                  </p>
                </div>
              ))}
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-100">
                  <tr>
                    <Th>الموظف</Th>
                    <Th>الحسابات</Th>
                    <Th>الحركات</Th>
                    <Th>مسلَّم له</Th>
                    <Th>مصروف / مسدَّد</Th>
                    <Th>الرصيد</Th>
                    <Th>الحالة</Th>
                  </tr>
                </thead>
                <tbody>
                  {report.rows.map((row) => {
                    const v = verdict(row.balance);
                    return (
                      <tr key={row.person} className="border-b border-slate-200">
                        <Td>
                          <button
                            onClick={() =>
                              setPerson(person === row.person ? null : row.person)
                            }
                            className="font-bold text-blue-700 hover:underline"
                          >
                            {row.person}
                          </button>
                        </Td>
                        <Td>{row.accounts.join("، ")}</Td>
                        <Td>{row.lines.length}</Td>
                        <Td>
                          <Money value={row.given} />
                        </Td>
                        <Td>
                          <Money value={row.settled} />
                        </Td>
                        <Td>
                          <Money value={Math.abs(row.balance)} bold />
                        </Td>
                        <Td className={v.cls}>{v.text}</Td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-slate-100 font-bold">
                  <tr>
                    <Td colSpan={3}>الإجمالي</Td>
                    <Td>
                      <Money value={report.totals.given} bold />
                    </Td>
                    <Td>
                      <Money value={report.totals.settled} bold />
                    </Td>
                    <Td>
                      <Money value={report.totals.balance} bold />
                    </Td>
                    <Td>{""}</Td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </>
        )}

        {report.unnamed.length > 0 && (
          <div className="mt-5">
            <Banner tone="warn">
              <b>{report.unnamed.length}</b> حركة سلف أو عهدة بلا اسم موظف — لا
              يمكن نسبتها لأحد. حدّد «الدافع / المستلم» فيها من الجدول أدناه.
            </Banner>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <Th>القيد</Th>
                  <Th>التاريخ</Th>
                  <Th>البيان</Th>
                  <Th>مدين</Th>
                  <Th>دائن</Th>
                  <Th>المبلغ</Th>
                  <Th>الإجراء</Th>
                </tr>
              </thead>
              <tbody>
                {report.unnamed.map((m) => (
                  <tr key={m.id} className="border-b border-slate-200">
                    <Td>{m.entryNo}</Td>
                    <Td>{m.date}</Td>
                    <Td>{m.description || "—"}</Td>
                    <Td>{m.debitCode}</Td>
                    <Td>{m.creditCode}</Td>
                    <Td>
                      <Money value={m.amount} />
                    </Td>
                    <Td>
                      <button
                        onClick={() => onEdit(m)}
                        className="rounded-lg bg-blue-600 px-3 py-2 font-medium text-white"
                      >
                        تحديد الموظف
                      </button>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      {selected && (
        <Panel
          title={`كشف حساب — ${selected.person}`}
          subtitle={`${selected.lines.length} حركة · الرصيد ${fmt(
            Math.abs(selected.balance)
          )} د.ك ${verdict(selected.balance).text}`}
        >
          <button
            onClick={() => setPerson(null)}
            className="mb-4 text-sm text-slate-500 hover:underline"
          >
            إغلاق الكشف
          </button>

          <div className="max-h-[30rem] overflow-auto">
            <table className="w-full text-right text-sm">
              <thead className="sticky top-0 bg-slate-100">
                <tr>
                  <Th>القيد</Th>
                  <Th>التاريخ</Th>
                  <Th>البيان</Th>
                  <Th>الحساب</Th>
                  <Th>مسلَّم</Th>
                  <Th>مصروف / مسدَّد</Th>
                  <Th>الرصيد</Th>
                  <Th>تعديل</Th>
                </tr>
              </thead>
              <tbody>
                {selected.lines.map((line) => (
                  <tr key={line.movement.id} className="border-b border-slate-100">
                    <Td>{line.movement.entryNo}</Td>
                    <Td>{line.movement.date}</Td>
                    <Td>{line.movement.description || "—"}</Td>
                    <Td>{line.account}</Td>
                    <Td>{line.given ? <Money value={line.given} /> : "—"}</Td>
                    <Td>{line.settled ? <Money value={line.settled} /> : "—"}</Td>
                    <Td>
                      <Money value={line.balance} />
                    </Td>
                    <Td>
                      <button
                        onClick={() => onEdit(line.movement)}
                        className="rounded-lg bg-blue-50 px-3 py-1 text-blue-700"
                      >
                        تعديل
                      </button>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      )}
    </>
  );
}

/* ================================================================== */
/* استلام مواد المواقع                                                 */
/* ================================================================== */

function MaterialsPage({
  year,
  projects,
  materials,
  receipts,
  setMaterials,
  setReceipts,
}: {
  year: number;
  projects: Project[];
  materials: Material[];
  receipts: MaterialReceipt[];
  setMaterials: Dispatch<SetStateAction<Material[]>>;
  setReceipts: Dispatch<SetStateAction<MaterialReceipt[]>>;
}) {
  const blank = {
    date: "",
    project: "",
    material: "",
    quantity: "",
    unitPrice: "",
    receivedBy: "",
    note: "",
  };

  const [form, setForm] = useState(blank);
  const [error, setError] = useState("");
  const [projectFilter, setProjectFilter] = useState("الكل");
  const [showCatalogue, setShowCatalogue] = useState(false);
  const [newMaterial, setNewMaterial] = useState({ name: "", unitPrice: "" });

  const set = (key: keyof typeof blank, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  // اختيار المادة يملأ سعرها الاسترشادي، ويبقى قابلاً للتعديل
  const pickMaterial = (name: string) => {
    const found = materials.find((m) => m.name === name);
    setForm((prev) => ({
      ...prev,
      material: name,
      unitPrice: found?.unitPrice != null ? String(found.unitPrice) : "",
    }));
  };

  const filtered = useMemo(
    () =>
      receipts
        .filter((r) => projectFilter === "الكل" || r.project === projectFilter)
        .sort((a, b) => (a.date === b.date ? 0 : a.date < b.date ? 1 : -1)),
    [receipts, projectFilter]
  );

  const totalCost = round3(
    filtered.reduce((sum, r) => sum + (receiptCost(r) ?? 0), 0)
  );
  const missingPrice = filtered.filter((r) => r.unitPrice == null);

  const byProject = useMemo(() => {
    const map = new Map<string, { count: number; cost: number; gaps: number }>();
    for (const r of receipts) {
      const row = map.get(r.project) ?? { count: 0, cost: 0, gaps: 0 };
      row.count++;
      const cost = receiptCost(r);
      if (cost == null) row.gaps++;
      else row.cost = round3(row.cost + cost);
      map.set(r.project, row);
    }
    return [...map.entries()].sort((a, b) => b[1].cost - a[1].cost);
  }, [receipts]);

  const add = () => {
    const quantity = round3(Number(form.quantity) || 0);
    const checks: [boolean, string][] = [
      [!form.date, "التاريخ مطلوب"],
      [!form.project, "المشروع مطلوب"],
      [!form.material, "نوع المادة مطلوب"],
      [quantity <= 0, "الكمية يجب أن تكون أكبر من صفر"],
      [!form.receivedBy.trim(), "اسم المستلم مطلوب"],
    ];
    const failed = checks.find(([bad]) => bad);
    if (failed) return setError(failed[1]);

    setReceipts((prev) => [
      ...prev,
      {
        id: newId(),
        date: form.date,
        fiscalYear: fiscalYearOf(form.date),
        project: form.project,
        material: form.material,
        quantity,
        unitPrice: form.unitPrice === "" ? null : round3(Number(form.unitPrice)),
        receivedBy: form.receivedBy.trim(),
        note: form.note.trim(),
      },
    ]);
    setForm(blank);
    setError("");
  };

  return (
    <>
      <Panel
        title={`استلام مواد المواقع ${year}`}
        subtitle="سجلّ عيني لما وصل كل موقع — لا يُنتج قيوداً محاسبية"
      >
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <Field label="التاريخ">
            <input
              type="date"
              value={form.date}
              onChange={(e) => set("date", e.target.value)}
              className={inputClass}
            />
          </Field>

          <Field label="المشروع">
            <select
              value={form.project}
              onChange={(e) => set("project", e.target.value)}
              className={inputClass}
            >
              <option value="">اختر المشروع</option>
              {projects.map((p) => (
                <option key={p.id} value={p.name}>
                  {p.name}
                </option>
              ))}
            </select>
          </Field>

          <Field label="نوع المادة">
            <select
              value={form.material}
              onChange={(e) => pickMaterial(e.target.value)}
              className={inputClass}
            >
              <option value="">اختر المادة</option>
              {materials.map((m) => (
                <option key={m.id} value={m.name}>
                  {m.name}
                  {m.unitPrice == null ? " (بلا سعر)" : ` — ${fmt(m.unitPrice)}`}
                </option>
              ))}
            </select>
          </Field>

          <Field label="الكمية">
            <input
              type="number"
              step="0.001"
              min="0"
              value={form.quantity}
              onChange={(e) => set("quantity", e.target.value)}
              className={inputClass}
            />
          </Field>

          <Field
            label="سعر الوحدة"
            hint="اتركه فارغاً إن لم يكن معروفاً — لن تُحتسب تكلفة"
          >
            <input
              type="number"
              step="0.001"
              min="0"
              value={form.unitPrice}
              onChange={(e) => set("unitPrice", e.target.value)}
              className={inputClass}
            />
          </Field>

          <Field label="المستلم">
            <input
              type="text"
              value={form.receivedBy}
              onChange={(e) => set("receivedBy", e.target.value)}
              placeholder="اسم المستلم في الموقع"
              className={inputClass}
            />
          </Field>
        </div>

        <div className="mt-4 flex flex-wrap items-end gap-4">
          <div className="flex-1">
            <Field label="ملاحظات">
              <input
                type="text"
                value={form.note}
                onChange={(e) => set("note", e.target.value)}
                className={inputClass}
              />
            </Field>
          </div>
          <div className="rounded-lg bg-slate-100 px-4 py-3 font-bold">
            التكلفة:{" "}
            {form.unitPrice === "" || !form.quantity
              ? "—"
              : `${fmt(round3(Number(form.quantity) * Number(form.unitPrice)))} د.ك`}
          </div>
        </div>

        {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

        <button
          onClick={add}
          className="mt-4 rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
        >
          تسجيل الاستلام
        </button>
      </Panel>

      <Panel title="ملخص حسب المشروع">
        {byProject.length === 0 ? (
          <Empty>لا توجد سجلات استلام في هذه السنة</Empty>
        ) : (
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-100">
              <tr>
                <Th>المشروع</Th>
                <Th>عدد السجلات</Th>
                <Th>التكلفة المحتسبة</Th>
                <Th>سجلات بلا سعر</Th>
              </tr>
            </thead>
            <tbody>
              {byProject.map(([project, row]) => (
                <tr key={project} className="border-b border-slate-200">
                  <Td>{project}</Td>
                  <Td>{row.count}</Td>
                  <Td>
                    <Money value={row.cost} />
                  </Td>
                  <Td className={row.gaps ? "text-amber-700 font-bold" : ""}>
                    {row.gaps || "—"}
                  </Td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Panel>

      <Panel title={`سجل الاستلام (${filtered.length})`}>
        <div className="mb-4 max-w-sm">
          <Field label="تصفية بالمشروع">
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className={inputClass}
            >
              <option value="الكل">جميع المشاريع</option>
              {[...new Set(receipts.map((r) => r.project))].map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </Field>
        </div>

        {missingPrice.length > 0 && (
          <Banner tone="warn">
            <b>{missingPrice.length}</b> سجل بلا سعر وحدة، فلا تُحتسب تكلفته.
            حدّد السعر في كتالوج المواد أو في السجل نفسه.
          </Banner>
        )}

        {filtered.length === 0 ? (
          <Empty>لا توجد سجلات</Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <Th>التاريخ</Th>
                  <Th>المشروع</Th>
                  <Th>المادة</Th>
                  <Th>الكمية</Th>
                  <Th>سعر الوحدة</Th>
                  <Th>التكلفة</Th>
                  <Th>المستلم</Th>
                  <Th>حذف</Th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => {
                  const cost = receiptCost(r);
                  return (
                    <tr key={r.id} className="border-b border-slate-200">
                      <Td>{r.date}</Td>
                      <Td>{r.project}</Td>
                      <Td>{r.material}</Td>
                      <Td>{fmt(r.quantity)}</Td>
                      <Td>{r.unitPrice == null ? "—" : fmt(r.unitPrice)}</Td>
                      <Td>
                        {cost == null ? (
                          <span className="text-amber-700">بلا سعر</span>
                        ) : (
                          <Money value={cost} />
                        )}
                      </Td>
                      <Td>{r.receivedBy}</Td>
                      <Td>
                        <button
                          onClick={() => {
                            if (window.confirm(`حذف سجل «${r.material}»؟`)) {
                              setReceipts((prev) =>
                                prev.filter((x) => x.id !== r.id)
                              );
                            }
                          }}
                          className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                        >
                          حذف
                        </button>
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-100 font-bold">
                <tr>
                  <Td colSpan={5}>إجمالي التكلفة المحتسبة</Td>
                  <Td>
                    <Money value={totalCost} bold />
                  </Td>
                  <Td colSpan={2}>{""}</Td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </Panel>

      <Panel title="كتالوج المواد">
        <button
          onClick={() => setShowCatalogue(!showCatalogue)}
          className="mb-4 rounded-lg bg-slate-200 px-5 py-2 font-bold"
        >
          {showCatalogue ? "إخفاء" : `عرض وتحرير (${materials.length} صنف)`}
        </button>

        {showCatalogue && (
          <>
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <Th>نوع المادة</Th>
                  <Th>سعر الوحدة</Th>
                  <Th>حذف</Th>
                </tr>
              </thead>
              <tbody>
                {materials.map((m) => (
                  <tr key={m.id} className="border-b border-slate-200">
                    <Td>{m.name}</Td>
                    <Td>
                      <input
                        type="number"
                        step="0.001"
                        min="0"
                        value={m.unitPrice ?? ""}
                        placeholder="بلا سعر"
                        onChange={(e) =>
                          setMaterials((prev) =>
                            prev.map((x) =>
                              x.id === m.id
                                ? {
                                    ...x,
                                    unitPrice:
                                      e.target.value === ""
                                        ? null
                                        : round3(Number(e.target.value)),
                                  }
                                : x
                            )
                          )
                        }
                        className="w-40 rounded-lg border border-slate-300 px-3 py-2"
                      />
                    </Td>
                    <Td>
                      <button
                        onClick={() =>
                          setMaterials((prev) => prev.filter((x) => x.id !== m.id))
                        }
                        className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                      >
                        حذف
                      </button>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="mt-4 flex flex-wrap gap-3">
              <input
                type="text"
                value={newMaterial.name}
                onChange={(e) =>
                  setNewMaterial((p) => ({ ...p, name: e.target.value }))
                }
                placeholder="اسم المادة"
                className={`${inputClass} flex-1`}
              />
              <input
                type="number"
                step="0.001"
                value={newMaterial.unitPrice}
                onChange={(e) =>
                  setNewMaterial((p) => ({ ...p, unitPrice: e.target.value }))
                }
                placeholder="سعر الوحدة (اختياري)"
                className={`${inputClass} flex-1`}
              />
              <button
                onClick={() => {
                  const name = newMaterial.name.trim();
                  if (!name || materials.some((m) => m.name === name)) return;
                  setMaterials((prev) => [
                    ...prev,
                    {
                      id: newId(),
                      name,
                      unitPrice:
                        newMaterial.unitPrice === ""
                          ? null
                          : round3(Number(newMaterial.unitPrice)),
                    },
                  ]);
                  setNewMaterial({ name: "", unitPrice: "" });
                }}
                className="rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
              >
                إضافة مادة
              </button>
            </div>
          </>
        )}
      </Panel>
    </>
  );
}

/* ================================================================== */
/* دليل الحسابات                                                       */
/* ================================================================== */

function ChartPage() {
  const [onlyPostable, setOnlyPostable] = useState(false);
  const rows = onlyPostable
    ? CHART_OF_ACCOUNTS.filter((a) => a.postable)
    : CHART_OF_ACCOUNTS;

  return (
    <Panel
      title="دليل الحسابات"
      subtitle={`${CHART_OF_ACCOUNTS.length} حساباً — منقول من الإكسل، ومصدر واحد لكل الشاشات`}
    >
      <label className="mb-4 flex items-center gap-2 text-sm font-medium">
        <input
          type="checkbox"
          checked={onlyPostable}
          onChange={(e) => setOnlyPostable(e.target.checked)}
        />
        عرض حسابات الترحيل فقط (إخفاء الحسابات الرئيسية التجميعية)
      </label>

      <div className="overflow-x-auto">
        <table className="w-full text-right text-sm">
          <thead className="bg-slate-100">
            <tr>
              <Th>رقم الحساب</Th>
              <Th>اسم الحساب</Th>
              <Th>الحساب الرئيسي</Th>
              <Th>التصنيف</Th>
              <Th>الطبيعة</Th>
              <Th>يظهر في</Th>
              <Th>يسمح بالترحيل</Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((a: Account) => (
              <tr
                key={a.code}
                className={`border-b border-slate-200 ${
                  a.postable ? "" : "bg-slate-50 font-bold"
                }`}
              >
                <Td>{a.code}</Td>
                <Td>
                  <span style={{ paddingRight: `${(a.level - 1) * 16}px` }}>
                    {a.name}
                  </span>
                </Td>
                <Td>{a.parent || "—"}</Td>
                <Td>{a.type}</Td>
                <Td>{a.nature}</Td>
                <Td>{a.statement}</Td>
                <Td>
                  {a.postable ? (
                    <span className="text-green-700">نعم</span>
                  ) : (
                    <span className="text-slate-400">لا — حساب تجميعي</span>
                  )}
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  );
}

/* ================================================================== */
/* الأرصدة الافتتاحية                                                  */
/* ================================================================== */

function OpeningPage({
  year,
  opening,
  totals,
  setYearOpening,
}: {
  year: number;
  opening: YearOpening;
  totals: ReturnType<typeof openingTotals>;
  setYearOpening: (next: YearOpening) => void;
}) {
  const update = (code: string, side: "debit" | "credit", value: string) =>
    setYearOpening({
      ...opening,
      // حساب واحد لا يحمل رصيداً مديناً ودائناً معاً
      [code]: {
        debit: side === "debit" ? value : "",
        credit: side === "credit" ? value : "",
      },
    });

  const resultAccounts = openingOnResultAccounts(opening);
  const rows = POSTABLE_ACCOUNTS;

  return (
    <Panel
      title={`الأرصدة الافتتاحية ${year}`}
      subtitle="لا تُعتمد في أي تقرير إلا إذا تساوى المدين مع الدائن"
    >
      {resultAccounts.length > 0 && (
        <Banner tone="warn">
          توجد أرصدة افتتاحية على حسابات نتيجة ({resultAccounts.join("، ")}) —
          الأرصدة الافتتاحية تخص حسابات المركز المالي فقط.
        </Banner>
      )}

      <div className="max-h-[32rem] overflow-auto">
        <table className="w-full text-right text-sm">
          <thead className="sticky top-0 bg-slate-100">
            <tr>
              <Th>رقم الحساب</Th>
              <Th>اسم الحساب</Th>
              <Th>مدين</Th>
              <Th>دائن</Th>
            </tr>
          </thead>
          <tbody>
            {rows.map((account) => {
              const row = opening[account.code];
              const hasDebit = !!row?.debit && Number(row.debit) !== 0;
              const hasCredit = !!row?.credit && Number(row.credit) !== 0;
              return (
                <tr key={account.code} className="border-b border-slate-200">
                  <Td>{account.code}</Td>
                  <Td>{account.name}</Td>
                  <Td>
                    <input
                      type="number"
                      step="0.001"
                      min="0"
                      disabled={hasCredit}
                      value={row?.debit ?? ""}
                      onChange={(e) => update(account.code, "debit", e.target.value)}
                      placeholder="0.000"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 disabled:bg-slate-100"
                    />
                  </Td>
                  <Td>
                    <input
                      type="number"
                      step="0.001"
                      min="0"
                      disabled={hasDebit}
                      value={row?.credit ?? ""}
                      onChange={(e) => update(account.code, "credit", e.target.value)}
                      placeholder="0.000"
                      className="w-full rounded-lg border border-slate-300 px-3 py-2 disabled:bg-slate-100"
                    />
                  </Td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-4 rounded-lg bg-slate-100 px-4 py-3 font-bold">
        الإجمالي — مدين {fmt(totals.debit)} · دائن {fmt(totals.credit)}
      </div>

      <div className="mt-4">
        {totals.balanced ? (
          <Banner tone="ok">✓ الأرصدة الافتتاحية متوازنة ومعتمدة</Banner>
        ) : (
          <Banner tone="error">
            ⚠ غير متوازنة — الفرق {fmt(totals.debit - totals.credit)} د.ك
          </Banner>
        )}
      </div>
    </Panel>
  );
}

/* ================================================================== */
/* الإعدادات                                                           */
/* ================================================================== */

function SettingsPage({
  year,
  years,
  state,
  broken,
  paymentGaps,
  onRollForward,
  onFix,
  onImport,
  onImportMaterials,
  company,
  setCompany,
  backupMeta,
  linkedFile,
  onRunBackup,
  onLinkFile,
  onUnlinkFile,
  exportTables,
  onExport,
}: {
  year: number;
  years: number[];
  state: ReturnType<typeof emptyState>;
  broken: { movement: Movement; problem: string }[];
  paymentGaps: string[];
  onRollForward: () => void;
  onFix: (movement: Movement) => void;
  onImport: (state: ReturnType<typeof emptyState>) => void;
  onImportMaterials: (
    materials: Material[],
    receipts: MaterialReceipt[]
  ) => void;
  company: CompanyProfile;
  setCompany: Dispatch<SetStateAction<CompanyProfile>>;
  backupMeta: BackupMeta | null;
  linkedFile: string | null;
  onRunBackup: () => void;
  onLinkFile: () => void;
  onUnlinkFile: () => void;
  exportTables: ExportTable[];
  onExport: (table: ExportTable) => void;
}) {
  const logoRef = useRef<HTMLInputElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const materialsRef = useRef<HTMLInputElement>(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const download = () => {
    const blob = new Blob([exportBackup(state)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = backupFileName();
    link.click();
    URL.revokeObjectURL(url);
    setMessage("تم تنزيل النسخة الاحتياطية");
  };

  const upload = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseBackup(String(reader.result));
        if (
          !window.confirm(
            `استيراد ${parsed.movements.length} حركة و ${parsed.projects.length} مشروع و ${parsed.contractors.length} عقد؟\n\nسيحل هذا محل البيانات الحالية بالكامل.`
          )
        ) {
          return;
        }
        onImport(parsed);
        setMessage(`تم استيراد ${parsed.movements.length} حركة`);
        setError("");
      } catch {
        setError("الملف غير صالح — تأكد أنه ملف نسخة احتياطية من هذا النظام");
      }
    };
    reader.readAsText(file);
  };

  /** يأخذ المواد وسجلات الاستلام فقط، ويترك الحركات والقيود كما هي */
  const uploadMaterialsOnly = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseBackup(String(reader.result));
        if (
          !window.confirm(
            `استيراد ${parsed.materials.length} صنف مادة و ${parsed.materialReceipts.length} سجل استلام؟\n\nلن تُمَس الحركات ولا القيود ولا الأرصدة الافتتاحية.`
          )
        ) {
          return;
        }
        onImportMaterials(parsed.materials, parsed.materialReceipts);
        setMessage(
          `تم استيراد ${parsed.materials.length} صنف و ${parsed.materialReceipts.length} سجل استلام`
        );
        setError("");
      } catch {
        setError("الملف غير صالح");
      }
    };
    reader.readAsText(file);
  };

  const perYear = years.map((y) => ({
    year: y,
    count: state.movements.filter((m) => m.fiscalYear === y).length,
  }));

  return (
    <>
      <Panel
        title="بيانات الشركة"
        subtitle="تظهر في ترويسة كل مطبوعة وفي سندات الصرف والقبض"
      >
        <div className="flex flex-wrap items-start gap-6">
          <div className="text-center">
            {company.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={company.logo}
                alt="شعار الشركة"
                className="mx-auto max-h-28 rounded-lg border border-slate-200 p-2"
              />
            ) : (
              <div className="flex h-28 w-28 items-center justify-center rounded-lg border-2 border-dashed border-slate-300 text-sm text-slate-400">
                لا يوجد شعار
              </div>
            )}

            <div className="mt-3 flex flex-col gap-2">
              <button
                onClick={() => logoRef.current?.click()}
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-bold text-white"
              >
                {company.logo ? "تغيير الشعار" : "رفع الشعار"}
              </button>
              {company.logo && (
                <button
                  onClick={() => setCompany((p) => ({ ...p, logo: "" }))}
                  className="rounded-lg bg-red-50 px-4 py-2 text-sm text-red-700"
                >
                  إزالة
                </button>
              )}
            </div>

            <input
              ref={logoRef}
              type="file"
              accept="image/png,image/jpeg,image/svg+xml,image/webp"
              hidden
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                if (file.size > 400 * 1024) {
                  setError("حجم الشعار كبير — اختر صورة أصغر من 400 كيلوبايت");
                  return;
                }
                const reader = new FileReader();
                reader.onload = () => {
                  // يُخزَّن كـ data URL ليُطبع بلا اتصال بالشبكة
                  setCompany((p) => ({ ...p, logo: String(reader.result) }));
                  setMessage("تم حفظ الشعار");
                  setError("");
                };
                reader.readAsDataURL(file);
              }}
            />
          </div>

          <div className="grid min-w-[20rem] flex-1 grid-cols-1 gap-4 md:grid-cols-2">
            {(
              [
                ["name", "اسم الشركة"],
                ["nameEn", "الاسم بالإنجليزية"],
                ["crNumber", "رقم السجل التجاري"],
                ["phone", "الهاتف"],
                ["email", "البريد الإلكتروني"],
                ["address", "العنوان"],
              ] as [keyof CompanyProfile, string][]
            ).map(([key, label]) => (
              <Field key={key} label={label}>
                <input
                  type="text"
                  value={company[key]}
                  onChange={(e) =>
                    setCompany((p) => ({ ...p, [key]: e.target.value }))
                  }
                  className={inputClass}
                />
              </Field>
            ))}
          </div>
        </div>

        <p className="mt-4 text-sm text-slate-600">
          الشعار يُحفظ داخل بياناتك ويخرج مع النسخة الاحتياطية. يُفضّل ملف PNG
          بخلفية شفافة وارتفاع 150 بكسل تقريباً.
        </p>
      </Panel>

      <Panel
        title="النسخ الاحتياطي والاستيراد"
        subtitle="البيانات محفوظة في متصفح هذا الجهاز فقط"
      >
        <Banner tone="warn">
          مسح بيانات المتصفح يمحو كل الدفاتر. نزّل نسخة احتياطية بانتظام.
        </Banner>

        {/* الحفظ المباشر إلى ملف ثابت */}
        <div className="mb-5 rounded-xl border border-slate-200 bg-slate-50 p-4">
          <p className="mb-2 font-bold">الحفظ المباشر إلى ملف</p>

          {linkedFile ? (
            <p className="mb-3 text-sm">
              مرتبط بالملف: <b>{linkedFile}</b> — كل حفظ يكتب فيه مباشرة بلا
              نوافذ.
            </p>
          ) : supportsDirectSave() ? (
            <p className="mb-3 text-sm text-slate-600">
              اختر ملفاً مرة واحدة، ثم يصبح الحفظ بضغطة واحدة تكتب فيه دائماً —
              بلا نوافذ ولا تراكم ملفات في مجلد التنزيلات.
            </p>
          ) : (
            <p className="mb-3 text-sm text-amber-800">
              متصفحك لا يدعم الكتابة المباشرة في الملفات. استخدم «تنزيل نسخة
              احتياطية»، أو افتح النظام في Chrome أو Edge.
            </p>
          )}

          <div className="flex flex-wrap gap-3">
            {supportsDirectSave() && (
              <button
                onClick={onLinkFile}
                className="rounded-lg bg-slate-900 px-5 py-2 font-bold text-white"
              >
                {linkedFile ? "تغيير الملف المرتبط" : "اختر ملف النسخة الاحتياطية"}
              </button>
            )}
            {linkedFile && (
              <button
                onClick={onUnlinkFile}
                className="rounded-lg bg-slate-200 px-5 py-2 font-bold"
              >
                فكّ الارتباط
              </button>
            )}
          </div>

          <p className="mt-3 text-sm">
            آخر نسخة:{" "}
            {backupMeta ? (
              <b>
                {new Date(backupMeta.at).toLocaleString("ar")} (قبل{" "}
                {daysSince(backupMeta.at)} يوماً)
              </b>
            ) : (
              <span className="text-red-600 font-bold">لم تُؤخذ نسخة بعد</span>
            )}
          </p>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={onRunBackup}
            className="rounded-lg bg-green-600 px-6 py-3 font-bold text-white"
          >
            💾 حفظ نسخة احتياطية الآن
          </button>
          <button
            onClick={download}
            className="rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
          >
            تنزيل نسخة احتياطية
          </button>
          <button
            onClick={() => materialsRef.current?.click()}
            className="rounded-lg bg-slate-200 px-6 py-3 font-bold"
          >
            استيراد المواد فقط
          </button>
          <button
            onClick={() => fileRef.current?.click()}
            className="rounded-lg border border-red-300 bg-red-50 px-6 py-3 font-bold text-red-700"
          >
            استيراد كامل (يستبدل كل شيء)
          </button>

          <input
            ref={fileRef}
            type="file"
            accept="application/json,.json"
            hidden
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) upload(file);
              e.target.value = "";
            }}
          />
          <input
            ref={materialsRef}
            type="file"
            accept="application/json,.json"
            hidden
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) uploadMaterialsOnly(file);
              e.target.value = "";
            }}
          />
        </div>

        <p className="mt-3 text-sm text-slate-600">
          «استيراد المواد فقط» يضيف كتالوج المواد وسجلات الاستلام دون المساس
          بحركاتك وتصحيحاتك. أما «الاستيراد الكامل» فيمحو كل ما في النظام ويستبدله
          بمحتوى الملف.
        </p>

        {message && <p className="mt-3 text-sm font-medium text-green-700">{message}</p>}
        {error && <p className="mt-3 text-sm font-medium text-red-600">{error}</p>}

        <div className="mt-5 grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
          {[
            ["إجمالي الحركات", state.movements.length],
            ["المشاريع", state.projects.length],
            ["العقود", state.contractors.length],
            ["سنوات بها أرصدة افتتاحية", Object.keys(state.openingBalances).length],
          ].map(([label, count]) => (
            <div key={String(label)} className="rounded-xl border border-slate-200 p-4">
              <p className="text-slate-500">{label}</p>
              <p className="mt-1 text-xl font-bold">{count}</p>
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap gap-3 text-sm">
          {perYear.map((p) => (
            <span key={p.year} className="rounded-lg bg-slate-100 px-4 py-2 font-medium">
              {p.year}: {p.count} حركة
            </span>
          ))}
        </div>
      </Panel>

      <Panel
        title="التصدير إلى Excel"
        subtitle={`ملفات CSV تفتح في Excel بالعربية سليمة — مقيّدة بالسنة ${year} والفترة المعروضة`}
      >
        <div className="flex flex-wrap gap-3">
          {exportTables.map((table) => (
            <button
              key={table.name}
              onClick={() => onExport(table)}
              disabled={table.rows.length <= 1}
              className="rounded-lg border border-slate-300 bg-white px-5 py-3 font-bold hover:bg-slate-50 disabled:opacity-40"
            >
              ⬇ {table.name}
              <span className="mr-2 text-xs font-normal text-slate-500">
                ({Math.max(0, table.rows.length - 1)} سطر)
              </span>
            </button>
          ))}
        </div>

        <p className="mt-4 text-sm text-slate-600">
          الملفات بترميز UTF-8 مع علامة ترتيب البايت، فتفتح العربية سليمة في
          Excel على ويندوز مباشرة بلا إعدادات استيراد.
        </p>
      </Panel>

      <Panel
        title="إقفال السنة والترحيل"
        subtitle="ينقل أرصدة حسابات المركز المالي إلى افتتاحي السنة التالية، ويقفل نتيجة السنة في الأرباح المرحّلة"
      >
        <button
          onClick={onRollForward}
          className="rounded-lg bg-slate-900 px-6 py-3 font-bold text-white"
        >
          ترحيل أرصدة {year} إلى افتتاحي {year + 1}
        </button>
      </Panel>

      <Panel
        title={`حركات ${year} التي تحتاج مراجعة`}
        subtitle="مستوردة ومحفوظة، لكنها مستبعدة من التقارير حتى تُصحَّح"
      >
        {broken.length === 0 ? (
          <Banner tone="ok">✓ كل حركات {year} تُنتج قيوداً صالحة</Banner>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <Th>القيد</Th>
                  <Th>التاريخ</Th>
                  <Th>البيان</Th>
                  <Th>مدين</Th>
                  <Th>دائن</Th>
                  <Th>المبلغ</Th>
                  <Th>السبب</Th>
                  <Th>الإجراء</Th>
                </tr>
              </thead>
              <tbody>
                {broken.map(({ movement, problem }) => (
                  <tr key={movement.id} className="border-b border-slate-200">
                    <Td>{movement.entryNo}</Td>
                    <Td>{movement.date || "—"}</Td>
                    <Td>{movement.description || "—"}</Td>
                    <Td>{movement.debitCode || "—"}</Td>
                    <Td>{movement.creditCode || "—"}</Td>
                    <Td>
                      <Money value={movement.amount} />
                    </Td>
                    <Td className="text-red-600">{problem}</Td>
                    <Td>
                      <button
                        onClick={() => onFix(movement)}
                        className="rounded-lg bg-blue-600 px-3 py-2 font-medium text-white"
                      >
                        تصحيح
                      </button>
                    </Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>

      <Panel title="فجوات في خرائط الترحيل" subtitle="منقولة كما هي من الإكسل">
        <div className="space-y-4 text-sm">
          <div>
            <p className="font-bold">بنود بلا حساب مقابل</p>
            {UNMAPPED_ITEMS.length === 0 ? (
              <p className="text-slate-500">لا يوجد</p>
            ) : (
              <ul className="mt-1 list-inside list-disc">
                {UNMAPPED_ITEMS.map((i) => (
                  <li key={i.code}>
                    {i.name} ({i.code})
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div>
            <p className="font-bold">طرق دفع مستخدمة وغير معرّفة في PostingMap</p>
            {paymentGaps.length === 0 ? (
              <p className="text-slate-500">لا يوجد</p>
            ) : (
              <ul className="mt-1 list-inside list-disc">
                {paymentGaps.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </Panel>
    </>
  );
}
/* ================================================================== */
/* تسجيل الدخول                                                        */
/* ================================================================== */

function LoginScreen({
  company,
  users,
  onLogin,
}: {
  company: CompanyProfile;
  users: User[];
  onLogin: (id: string) => void;
}) {
  const [selected, setSelected] = useState<User | null>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      const hash = await hashPin(pin);
      if (hash === selected.pinHash) {
        onLogin(selected.id);
      } else {
        setError("رقم الدخول غير صحيح");
        setPin("");
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <main
      dir="rtl"
      className="flex min-h-screen items-center justify-center bg-slate-900 p-6"
    >
      <div className="w-full max-w-md rounded-2xl bg-white p-8 shadow-2xl">
        <div className="mb-8 text-center">
          {company.logo ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={company.logo} alt="" className="mx-auto mb-4 max-h-20" />
          ) : null}
          <h1 className="text-2xl font-bold">{company.name}</h1>
          <p className="mt-1 text-sm text-slate-500">النظام المالي والمحاسبي</p>
        </div>

        {!selected ? (
          <>
            <p className="mb-4 text-sm font-bold">اختر المستخدم</p>
            <div className="space-y-2">
              {users.map((user) => (
                <button
                  key={user.id}
                  onClick={() => {
                    setSelected(user);
                    setPin("");
                    setError("");
                  }}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3 text-right hover:border-blue-400 hover:bg-blue-50"
                >
                  <div className="font-bold">{user.name}</div>
                  <div className="text-xs text-slate-500">
                    {user.jobTitle || roleDefinition(user.role).label}
                  </div>
                </button>
              ))}
            </div>
          </>
        ) : (
          <>
            <button
              onClick={() => setSelected(null)}
              className="mb-4 text-sm text-slate-500 hover:underline"
            >
              → اختيار مستخدم آخر
            </button>

            <div className="mb-4 rounded-xl bg-slate-50 p-4">
              <div className="font-bold">{selected.name}</div>
              <div className="text-xs text-slate-500">
                {selected.jobTitle || roleDefinition(selected.role).label}
              </div>
            </div>

            <Field label="رقم الدخول">
              <input
                type="password"
                inputMode="numeric"
                autoFocus
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setError("");
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") submit();
                }}
                className={`${inputClass} text-center text-2xl tracking-[0.5em]`}
              />
            </Field>

            {error && (
              <p className="mt-3 text-sm font-medium text-red-600">{error}</p>
            )}

            <button
              onClick={submit}
              disabled={!pin || busy}
              className="mt-5 w-full rounded-lg bg-slate-900 px-6 py-3 font-bold text-white disabled:bg-slate-300"
            >
              {busy ? "…" : "دخول"}
            </button>
          </>
        )}

        <p className="mt-8 text-center text-xs text-slate-400">
          التحقق يجري داخل المتصفح — ليس بديلاً عن حماية الخادم
        </p>
      </div>
    </main>
  );
}

/* ================================================================== */
/* إدارة المستخدمين والصلاحيات                                         */
/* ================================================================== */

const BLANK_USER = {
  name: "",
  jobTitle: "",
  role: "secretary" as RoleKey,
  pin: "",
  pin2: "",
};

function UsersPage({
  users,
  setUsers,
  currentUserId,
}: {
  users: User[];
  setUsers: Dispatch<SetStateAction<User[]>>;
  currentUserId: string | null;
}) {
  const [form, setForm] = useState(BLANK_USER);
  const [permissions, setPermissions] = useState<Permission[]>(
    roleDefinition("secretary").permissions
  );
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [showForm, setShowForm] = useState(false);

  const set = (key: keyof typeof BLANK_USER, value: string) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  const pickRole = (role: RoleKey) => {
    setForm((prev) => ({ ...prev, role }));
    // القالب يملأ الصلاحيات، ويبقى تعديلها حراً بعد ذلك
    if (role !== "custom") setPermissions(roleDefinition(role).permissions);
  };

  const toggle = (permission: Permission) =>
    setPermissions((prev) => {
      const next = prev.includes(permission)
        ? prev.filter((p) => p !== permission)
        : [...prev, permission];
      // أي تعديل يدوي يحوّل الدور إلى مخصّص
      setForm((f) => ({ ...f, role: "custom" }));
      return next;
    });

  const openNew = () => {
    setEditingId(null);
    setForm(BLANK_USER);
    setPermissions(roleDefinition("secretary").permissions);
    setError("");
    setShowForm(true);
  };

  const openEdit = (user: User) => {
    setEditingId(user.id);
    setForm({
      name: user.name,
      jobTitle: user.jobTitle,
      role: user.role,
      pin: "",
      pin2: "",
    });
    setPermissions(user.permissions);
    setError("");
    setShowForm(true);
  };

  const save = async () => {
    const name = form.name.trim();
    if (!name) return setError("اسم المستخدم مطلوب");
    if (users.some((u) => u.id !== editingId && u.name.trim() === name)) {
      return setError("يوجد مستخدم بنفس الاسم");
    }
    if (permissions.length === 0) {
      return setError("اختر صلاحية واحدة على الأقل");
    }
    // الرقم مطلوب للجديد، واختياري عند التعديل
    if (!editingId || form.pin) {
      if (form.pin.length < 4) return setError("رقم الدخول أربعة أرقام فأكثر");
      if (form.pin !== form.pin2) return setError("الرقمان غير متطابقين");
    }

    const pinHash = form.pin
      ? await hashPin(form.pin)
      : users.find((u) => u.id === editingId)?.pinHash ?? "";

    if (editingId) {
      setUsers((prev) =>
        prev.map((u) =>
          u.id === editingId
            ? { ...u, name, jobTitle: form.jobTitle.trim(), role: form.role, permissions, pinHash }
            : u
        )
      );
      setMessage(`تم تعديل ${name}`);
    } else {
      setUsers((prev) => [
        ...prev,
        {
          id: newId(),
          name,
          jobTitle: form.jobTitle.trim(),
          role: form.role,
          permissions,
          pinHash,
          active: true,
          createdAt: new Date().toISOString(),
        },
      ]);
      setMessage(`تم تسجيل ${name}`);
    }

    setShowForm(false);
    setEditingId(null);
    setError("");
  };

  const admins = users.filter(
    (u) => u.active && u.permissions.includes("users.manage")
  );

  return (
    <>
      <Panel
        title="المستخدمون والصلاحيات"
        subtitle={`${users.filter((u) => u.active).length} مستخدماً نشطاً`}
      >
        <Banner tone="warn">
          الصلاحيات هنا تنظّم الواجهة ولا تحمي البيانات: التحقق يجري داخل
          المتصفح، ومن يفتح أدوات المطوّر يستطيع تجاوزه. تصبح حماية حقيقية عند
          نقل النظام إلى خادم.
        </Banner>

        {users.length === 0 && (
          <Banner tone="warn">
            لا يوجد مستخدمون بعد، والنظام يعمل بكامل الصلاحيات بلا تسجيل دخول.
            <b> أول مستخدم تسجّله يفعّل شاشة الدخول</b> — فاجعله صاحب الشركة
            واحفظ رقمه، وإلا أُغلق عليك النظام.
          </Banner>
        )}

        <button
          onClick={showForm ? () => setShowForm(false) : openNew}
          className="mb-5 rounded-lg bg-blue-600 px-6 py-3 font-bold text-white"
        >
          {showForm ? "إخفاء النموذج" : "تسجيل مستخدم جديد"}
        </button>

        {showForm && (
          <div className="mb-6 rounded-xl border border-slate-200 p-5">
            <h4 className="mb-4 font-bold">
              {editingId ? "تعديل مستخدم" : "مستخدم جديد"}
            </h4>

            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <Field label="الاسم">
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  className={inputClass}
                />
              </Field>

              <Field label="الوظيفة">
                <input
                  type="text"
                  value={form.jobTitle}
                  onChange={(e) => set("jobTitle", e.target.value)}
                  placeholder="مثال: مدير عام مالي وإداري"
                  className={inputClass}
                />
              </Field>

              <Field
                label="رقم الدخول"
                hint={editingId ? "اتركه فارغاً للإبقاء على الرقم الحالي" : "أربعة أرقام فأكثر"}
              >
                <input
                  type="password"
                  inputMode="numeric"
                  value={form.pin}
                  onChange={(e) => set("pin", e.target.value)}
                  className={inputClass}
                />
              </Field>

              <Field label="تأكيد رقم الدخول">
                <input
                  type="password"
                  inputMode="numeric"
                  value={form.pin2}
                  onChange={(e) => set("pin2", e.target.value)}
                  className={inputClass}
                />
              </Field>
            </div>

            <div className="mt-5">
              <p className="mb-2 text-sm font-medium">الدور</p>
              <div className="flex flex-wrap gap-2">
                {ROLES.map((role) => (
                  <button
                    key={role.key}
                    onClick={() => pickRole(role.key)}
                    title={role.description}
                    className={`rounded-lg px-4 py-2 text-sm font-bold ${
                      form.role === role.key
                        ? "bg-blue-600 text-white"
                        : "bg-slate-100 hover:bg-slate-200"
                    }`}
                  >
                    {role.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-xs text-slate-500">
                {roleDefinition(form.role).description}
              </p>
              {(form.role === "owner" || form.role === "manager") && (
                <p className="mt-1 text-xs font-medium text-green-700">
                  هذان الدوران يُمنحان أي صلاحية تُضاف إلى النظام مستقبلاً
                  تلقائياً.
                </p>
              )}
            </div>

            <div className="mt-5">
              <div className="mb-3 flex flex-wrap items-center gap-3">
                <p className="text-sm font-medium">
                  الصلاحيات ({permissions.length} من {ALL_PERMISSIONS.length})
                </p>
                <button
                  onClick={() => {
                    setPermissions(ALL_PERMISSIONS);
                    setForm((f) => ({ ...f, role: "custom" }));
                  }}
                  className="rounded bg-slate-100 px-3 py-1 text-xs"
                >
                  تحديد الكل
                </button>
                <button
                  onClick={() => {
                    setPermissions([]);
                    setForm((f) => ({ ...f, role: "custom" }));
                  }}
                  className="rounded bg-slate-100 px-3 py-1 text-xs"
                >
                  إلغاء الكل
                </button>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                {PERMISSION_CATALOGUE.map((group) => (
                  <div
                    key={group.group}
                    className="rounded-xl border border-slate-200 p-4"
                  >
                    <p className="mb-2 font-bold">{group.group}</p>
                    <div className="space-y-2">
                      {group.items.map((item) => (
                        <label
                          key={item.key}
                          className="flex items-start gap-2 text-sm"
                        >
                          <input
                            type="checkbox"
                            checked={permissions.includes(item.key)}
                            onChange={() => toggle(item.key)}
                            className="mt-1"
                          />
                          <span>
                            {item.label}
                            {item.note && (
                              <span className="mr-1 text-xs font-bold text-red-600">
                                ({item.note})
                              </span>
                            )}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {error && (
              <p className="mt-4 text-sm font-medium text-red-600">{error}</p>
            )}

            <div className="mt-5 flex gap-3">
              <button
                onClick={save}
                className="rounded-lg bg-slate-900 px-6 py-3 font-bold text-white"
              >
                {editingId ? "حفظ التعديل" : "تسجيل المستخدم"}
              </button>
              <button
                onClick={() => setShowForm(false)}
                className="rounded-lg bg-slate-200 px-6 py-3 font-bold"
              >
                إلغاء
              </button>
            </div>
          </div>
        )}

        {message && (
          <p className="mb-4 text-sm font-medium text-green-700">{message}</p>
        )}

        {users.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-sm">
              <thead className="bg-slate-100">
                <tr>
                  <Th>الاسم</Th>
                  <Th>الوظيفة</Th>
                  <Th>الدور</Th>
                  <Th>الصلاحيات</Th>
                  <Th>الحالة</Th>
                  <Th>الإجراء</Th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => {
                  const isLastAdmin =
                    admins.length === 1 && admins[0].id === user.id;
                  return (
                    <tr key={user.id} className="border-b border-slate-200">
                      <Td>
                        <span className="font-bold">{user.name}</span>
                        {user.id === currentUserId && (
                          <span className="mr-2 rounded bg-green-100 px-2 py-1 text-xs text-green-800">
                            أنت
                          </span>
                        )}
                      </Td>
                      <Td>{user.jobTitle || "—"}</Td>
                      <Td>{roleDefinition(user.role).label}</Td>
                      <Td>
                        {user.permissions.length === ALL_PERMISSIONS.length
                          ? "كل الصلاحيات"
                          : `${user.permissions.length} صلاحية`}
                      </Td>
                      <Td>
                        {user.active ? (
                          <span className="text-green-700">نشط</span>
                        ) : (
                          <span className="text-slate-400">موقوف</span>
                        )}
                      </Td>
                      <Td>
                        <div className="flex gap-2">
                          <button
                            onClick={() => openEdit(user)}
                            className="rounded-lg bg-blue-50 px-3 py-2 text-blue-700"
                          >
                            تعديل
                          </button>
                          <button
                            onClick={() => {
                              if (isLastAdmin && user.active) {
                                setError(
                                  "لا يمكن إيقاف آخر مستخدم يملك إدارة المستخدمين — سيُغلق النظام على الجميع"
                                );
                                return;
                              }
                              setUsers((prev) =>
                                prev.map((u) =>
                                  u.id === user.id
                                    ? { ...u, active: !u.active }
                                    : u
                                )
                              );
                              setError("");
                            }}
                            className="rounded-lg bg-slate-100 px-3 py-2"
                          >
                            {user.active ? "إيقاف" : "تفعيل"}
                          </button>
                          <button
                            onClick={() => {
                              if (isLastAdmin) {
                                setError(
                                  "لا يمكن حذف آخر مستخدم يملك إدارة المستخدمين"
                                );
                                return;
                              }
                              if (window.confirm(`حذف المستخدم «${user.name}»؟`)) {
                                setUsers((prev) =>
                                  prev.filter((u) => u.id !== user.id)
                                );
                                setError("");
                              }
                            }}
                            className="rounded-lg bg-red-50 px-3 py-2 text-red-700"
                          >
                            حذف
                          </button>
                        </div>
                      </Td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </>
  );
}
/* ================================================================== */
/* اعتماد مراحل الإنجاز — شاشة المهندس المشرف                          */
/* ================================================================== */

function ApprovalsPage({
  contractors,
  projects,
  movements,
  approverName,
  canApprove,
  setContractors,
  onLog,
}: {
  contractors: Contractor[];
  projects: Project[];
  movements: Movement[];
  approverName: string;
  canApprove: boolean;
  setContractors: Dispatch<SetStateAction<Contractor[]>>;
  onLog: (
    action: AuditAction,
    entity: AuditEntity,
    summary: string,
    change?: { before?: string; after?: string }
  ) => void;
}) {
  const [projectFilter, setProjectFilter] = useState("الكل");
  const [note, setNote] = useState("");
  const [message, setMessage] = useState("");

  const visible = contractors.filter(
    (c) => projectFilter === "الكل" || c.project === projectFilter
  );

  const setApproval = (
    contractId: string,
    installmentNumber: number,
    approved: boolean
  ) => {
    setContractors((prev) =>
      prev.map((contract) =>
        contract.id !== contractId
          ? contract
          : {
              ...contract,
              installments: contract.installments.map((installment) =>
                installment.number !== installmentNumber
                  ? installment
                  : {
                      ...installment,
                      approved,
                      approvedBy: approved ? approverName : "",
                      approvedAt: approved ? new Date().toISOString() : "",
                      approvalNote: approved ? note.trim() : "",
                    }
              ),
            }
      )
    );
    const contract = contractors.find((c) => c.id === contractId);
    const installment = contract?.installments.find(
      (i) => i.number === installmentNumber
    );
    onLog(
      approved ? "اعتماد" : "إلغاء اعتماد",
      "دفعة",
      `عقد ${contract?.contractNumber ?? "?"} · الدفعة ${installmentNumber} · ${fmt(
        Number(installment?.value) || 0
      )} د.ك · ${contract?.project ?? ""}`,
      { after: approved && note.trim() ? note.trim() : undefined }
    );

    setNote("");
    setMessage(
      approved
        ? `تم اعتماد الدفعة ${installmentNumber} — أصبحت مستحقة للصرف`
        : `أُلغي اعتماد الدفعة ${installmentNumber}`
    );
  };

  return (
    <>
      <Panel
        title="اعتماد مراحل الإنجاز"
        subtitle="اعتماد المرحلة المنجزة يجعل دفعتها مستحقة للصرف — الصرف نفسه من اختصاص المحاسب"
      >
        {!canApprove && (
          <Banner tone="warn">
            لديك صلاحية الاطلاع فقط — الاعتماد يحتاج صلاحية «اعتماد إنجاز
            المراحل».
          </Banner>
        )}

        <div className="max-w-sm">
          <Field label="تصفية بالمشروع">
            <select
              value={projectFilter}
              onChange={(e) => setProjectFilter(e.target.value)}
              className={inputClass}
            >
              <option value="الكل">جميع المشاريع</option>
              {[...new Set(contractors.map((c) => c.project))].map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </Field>
        </div>

        {message && (
          <p className="mt-4 text-sm font-medium text-green-700">{message}</p>
        )}

        {projects.length === 0 && contractors.length === 0 && (
          <Empty>لا توجد عقود</Empty>
        )}
      </Panel>

      {visible.length === 0 ? (
        <Panel>
          <Empty>لا توجد عقود في هذا المشروع</Empty>
        </Panel>
      ) : (
        visible.map((contract) => {
          const payments = contractPayments(movements, contract.contractNumber);

          const approvedValue = round3(
            contract.installments
              .filter((i) => i.approved)
              .reduce((sum, i) => sum + (Number(i.value) || 0), 0)
          );
          const progress =
            contract.contractValue > 0
              ? (approvedValue / contract.contractValue) * 100
              : 0;

          return (
            <Panel
              key={contract.id}
              title={`${contract.project} — عقد ${contract.contractNumber}`}
              subtitle={`${contract.name} · ${contract.workType}`}
            >
              <div className="mb-4 grid grid-cols-2 gap-3 text-sm md:grid-cols-4">
                {[
                  ["قيمة العقد", contract.contractValue],
                  ["المعتمد إنجازه", approvedValue],
                  ["المدفوع فعلاً", payments.total],
                  [
                    "معتمد وغير مدفوع",
                    round3(approvedValue - payments.total),
                  ],
                ].map(([label, value]) => (
                  <div
                    key={String(label)}
                    className="rounded-xl border border-slate-200 p-3"
                  >
                    <p className="text-slate-500">{label}</p>
                    <p className="mt-1 font-bold">
                      <Money value={value as number} /> د.ك
                    </p>
                  </div>
                ))}
              </div>

              <div className="mb-5">
                <div className="h-3 w-full overflow-hidden rounded-full bg-slate-200">
                  <div
                    className="h-full bg-green-600"
                    style={{ width: `${Math.min(progress, 100)}%` }}
                  />
                </div>
                <p className="mt-1 text-xs text-slate-500">
                  نسبة الإنجاز المعتمد: {progress.toFixed(1)}%
                </p>
              </div>

              {canApprove && (
                <div className="mb-4 max-w-xl">
                  <Field
                    label="ملاحظة الاعتماد"
                    hint="تُحفظ مع الدفعة التي تعتمدها بعد كتابتها"
                  >
                    <input
                      type="text"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      placeholder="مثال: عُوين الموقع وتم صب السقف بالكامل"
                      className={inputClass}
                    />
                  </Field>
                </div>
              )}

              <div className="overflow-x-auto">
                <table className="w-full text-right text-sm">
                  <thead className="bg-slate-100">
                    <tr>
                      <Th>#</Th>
                      <Th>المرحلة والاستحقاق</Th>
                      <Th>القيمة</Th>
                      <Th>الاعتماد</Th>
                      <Th>حالة الصرف</Th>
                      <Th>الإجراء</Th>
                    </tr>
                  </thead>
                  <tbody>
                    {contract.installments.map((installment) => {
                      const value = round3(Number(installment.value) || 0);
                      const paid =
                        payments.byInstallment.get(installment.number) ?? 0;

                      const settlement = !installment.approved
                        ? { text: "لم تُستحق بعد", cls: "text-slate-400" }
                        : isZero(paid)
                        ? { text: "مستحقة وغير مدفوعة", cls: "font-bold text-amber-700" }
                        : paid + 0.0005 < value
                        ? { text: `مدفوع منها ${fmt(paid)}`, cls: "text-blue-700" }
                        : { text: "مدفوعة بالكامل", cls: "font-bold text-green-700" };

                      return (
                        <tr
                          key={installment.number}
                          className="border-b border-slate-100 align-top"
                        >
                          <Td>{installment.number}</Td>
                          <Td>
                            <div>{installment.condition || "—"}</div>
                            {installment.approvalNote && (
                              <div className="mt-1 text-xs text-slate-500">
                                ملاحظة: {installment.approvalNote}
                              </div>
                            )}
                          </Td>
                          <Td>
                            <Money value={value} />
                          </Td>
                          <Td>
                            {installment.approved ? (
                              <div>
                                <span className="font-bold text-green-700">
                                  ✓ معتمدة
                                </span>
                                {installment.approvedBy && (
                                  <div className="text-xs text-slate-500">
                                    {installment.approvedBy}
                                    {installment.approvedAt &&
                                      ` · ${installment.approvedAt.slice(0, 10)}`}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-slate-400">غير معتمدة</span>
                            )}
                          </Td>
                          <Td className={settlement.cls}>{settlement.text}</Td>
                          <Td>
                            {canApprove &&
                              (installment.approved ? (
                                <button
                                  onClick={() => {
                                    if (!isZero(paid)) {
                                      window.alert(
                                        "لا يمكن إلغاء اعتماد دفعة صُرف منها مبلغ. راجع المحاسب أولاً."
                                      );
                                      return;
                                    }
                                    setApproval(
                                      contract.id,
                                      installment.number,
                                      false
                                    );
                                  }}
                                  className="rounded-lg bg-slate-100 px-3 py-2"
                                >
                                  إلغاء الاعتماد
                                </button>
                              ) : (
                                <button
                                  onClick={() =>
                                    setApproval(
                                      contract.id,
                                      installment.number,
                                      true
                                    )
                                  }
                                  className="rounded-lg bg-green-600 px-4 py-2 font-bold text-white"
                                >
                                  اعتماد الإنجاز
                                </button>
                              ))}
                          </Td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </Panel>
          );
        })
      )}
    </>
  );
}
/* ================================================================== */
/* سجل التدقيق                                                         */
/* ================================================================== */

const AUDIT_TONE: Record<string, string> = {
  إنشاء: "bg-green-100 text-green-800",
  تعديل: "bg-blue-100 text-blue-800",
  حذف: "bg-red-100 text-red-800",
  اعتماد: "bg-emerald-100 text-emerald-800",
  "إلغاء اعتماد": "bg-amber-100 text-amber-900",
  ترحيل: "bg-purple-100 text-purple-800",
  استيراد: "bg-orange-100 text-orange-900",
  دخول: "bg-slate-100 text-slate-600",
  خروج: "bg-slate-100 text-slate-600",
};

function AuditPage({
  audit,
  onExport,
}: {
  audit: AuditEntry[];
  onExport: (table: ExportTable) => void;
}) {
  const [filter, setFilter] = useState(emptyAuditFilter());
  const [expanded, setExpanded] = useState<string | null>(null);

  const rows = useMemo(() => filterAudit(audit, filter), [audit, filter]);

  const set = (key: keyof typeof filter, value: string) =>
    setFilter((prev) => ({ ...prev, [key]: value }));

  const usersInLog = [...new Set(audit.map((e) => e.user))].sort();
  const actionsInLog = [...new Set(audit.map((e) => e.action))].sort();
  const entitiesInLog = [...new Set(audit.map((e) => e.entity))].sort();

  return (
    <Panel
      title="سجل التدقيق"
      subtitle={`${audit.length} قيد مسجّل · يوثّق التغييرات المؤثّرة دون القراءة والتصفّح`}
    >
      {audit.length === 0 ? (
        <>
          <Banner tone="warn">
            السجل فارغ — بدأ التوثيق من لحظة تفعيله، وما وقع قبله غير مسجّل.
          </Banner>
          <Empty>لم تُسجَّل تغييرات بعد</Empty>
        </>
      ) : (
        <>
          <div className="mb-4 grid grid-cols-1 gap-3 md:grid-cols-3 lg:grid-cols-6">
            <Field label="المستخدم">
              <select
                value={filter.user}
                onChange={(e) => set("user", e.target.value)}
                className={inputClass}
              >
                <option value="الكل">الكل</option>
                {usersInLog.map((u) => (
                  <option key={u}>{u}</option>
                ))}
              </select>
            </Field>

            <Field label="نوع الإجراء">
              <select
                value={filter.action}
                onChange={(e) => set("action", e.target.value)}
                className={inputClass}
              >
                <option value="الكل">الكل</option>
                {actionsInLog.map((a) => (
                  <option key={a}>{a}</option>
                ))}
              </select>
            </Field>

            <Field label="الموضوع">
              <select
                value={filter.entity}
                onChange={(e) => set("entity", e.target.value)}
                className={inputClass}
              >
                <option value="الكل">الكل</option>
                {entitiesInLog.map((en) => (
                  <option key={en}>{en}</option>
                ))}
              </select>
            </Field>

            <Field label="من تاريخ">
              <input
                type="date"
                value={filter.from}
                onChange={(e) => set("from", e.target.value)}
                className={inputClass}
              />
            </Field>

            <Field label="إلى تاريخ">
              <input
                type="date"
                value={filter.to}
                onChange={(e) => set("to", e.target.value)}
                className={inputClass}
              />
            </Field>

            <Field label="بحث">
              <input
                type="text"
                value={filter.search}
                onChange={(e) => set("search", e.target.value)}
                placeholder="كلمة من الوصف…"
                className={inputClass}
              />
            </Field>
          </div>

          <div className="mb-4 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setFilter(emptyAuditFilter())}
              className="rounded-lg bg-slate-200 px-4 py-2 font-bold no-print"
            >
              مسح الفلاتر
            </button>
            <button
              onClick={() =>
                onExport({
                  name: "سجل التدقيق",
                  rows: [
                    ["التاريخ والوقت", "المستخدم", "الإجراء", "الموضوع", "الوصف", "قبل", "بعد"],
                    ...rows.map((e) => [
                      formatAuditTime(e.at),
                      e.user,
                      e.action,
                      e.entity,
                      e.summary,
                      e.before ?? "",
                      e.after ?? "",
                    ]),
                  ],
                })
              }
              className="rounded-lg border border-slate-300 bg-white px-4 py-2 font-bold no-print"
            >
              ⬇ تصدير الظاهر
            </button>
            <span className="text-sm text-slate-500">
              الظاهر: {rows.length} من {audit.length}
            </span>
          </div>

          {rows.length === 0 ? (
            <Empty>لا توجد قيود مطابقة للفلاتر</Empty>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-right text-sm">
                <thead className="sticky top-0 z-10 bg-slate-100 shadow-sm">
                  <tr>
                    <Th>التاريخ والوقت</Th>
                    <Th>المستخدم</Th>
                    <Th>الإجراء</Th>
                    <Th>الموضوع</Th>
                    <Th>الوصف</Th>
                    <Th>التفاصيل</Th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((entry) => {
                    const hasDetails = !!(entry.before || entry.after);
                    const open = expanded === entry.id;
                    return (
                      <Fragment key={entry.id}>
                        <tr className="border-b border-slate-100 align-top">
                          <Td className="whitespace-nowrap tabular-nums">
                            {formatAuditTime(entry.at)}
                          </Td>
                          <Td>{entry.user}</Td>
                          <Td>
                            <span
                              className={`rounded px-2 py-1 text-xs font-bold ${
                                AUDIT_TONE[entry.action] ?? "bg-slate-100"
                              }`}
                            >
                              {entry.action}
                            </span>
                          </Td>
                          <Td>{entry.entity}</Td>
                          <Td>{entry.summary}</Td>
                          <Td>
                            {hasDetails ? (
                              <button
                                onClick={() => setExpanded(open ? null : entry.id)}
                                className="rounded-lg bg-slate-100 px-3 py-1 no-print"
                              >
                                {open ? "إخفاء" : "عرض"}
                              </button>
                            ) : (
                              <span className="text-slate-300">—</span>
                            )}
                          </Td>
                        </tr>

                        {open && (
                          <tr className="border-b border-slate-200 bg-slate-50">
                            <Td colSpan={6}>
                              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                                {entry.before && (
                                  <div className="rounded-lg border border-red-200 bg-red-50 p-3">
                                    <p className="mb-1 text-xs font-bold text-red-800">
                                      قبل
                                    </p>
                                    <p className="text-sm">{entry.before}</p>
                                  </div>
                                )}
                                {entry.after && (
                                  <div className="rounded-lg border border-green-200 bg-green-50 p-3">
                                    <p className="mb-1 text-xs font-bold text-green-800">
                                      بعد
                                    </p>
                                    <p className="text-sm">{entry.after}</p>
                                  </div>
                                )}
                              </div>
                            </Td>
                          </tr>
                        )}
                      </Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          <p className="mt-4 text-sm text-slate-500">
            يُحتفظ بآخر {AUDIT_LIMIT} قيد، ثم تُحذف الأقدم. السجل يخرج مع النسخة
            الاحتياطية.
          </p>
        </>
      )}
    </Panel>
  );
}
