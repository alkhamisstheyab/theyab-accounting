/**
 * التخزين والنسخ الاحتياطي
 *
 * البيانات في localStorage (متصفح واحد). هذا الملف يعزل ذلك خلف واجهة
 * واحدة ويتكفّل بترحيل البيانات القديمة، حتى يكون الانتقال لاحقاً إلى
 * قاعدة بيانات تغييراً في مكان واحد.
 */

import {
  Movement,
  OpeningBalances,
  YearOpening,
  fiscalYearOf,
  itemAccount,
  round3,
} from "./accounting";
import { ALL_PERMISSIONS, Permission, RoleKey } from "./permissions";
import { AUDIT_LIMIT, AuditEntry } from "./audit";

export type Project = {
  id: string;
  name: string;
  budget: number;
  status: string;
};

/**
 * دفعة عقد.
 *
 * الاعتماد والدفع أمران منفصلان: المهندس يعتمد إنجاز المرحلة فتصير الدفعة
 * مستحقة، ثم يصرفها المحاسب. حالة الدفع الفعلية تُحسب من القيود المرتبطة
 * لا من هذا الحقل.
 */
export type Installment = {
  number: number;
  value: string;
  /** شرط الاستحقاق كما في العقد */
  condition: string;
  /** حالة الدفع المسجّلة يدوياً */
  status: string;
  /** هل اعتُمد إنجاز المرحلة؟ */
  approved: boolean;
  /** اسم من اعتمدها */
  approvedBy: string;
  /** ISO datetime */
  approvedAt: string;
  /** ملاحظة المهندس عند الاعتماد */
  approvalNote: string;
};

/** الدفعة مستحقة متى اعتُمد إنجاز مرحلتها */
export const isInstallmentDue = (installment: Installment): boolean =>
  installment.approved;

export type Contractor = {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  project: string;
  contractNumber: string;
  contractType: string;
  workType: string;
  contractValue: number;
  installmentsCount: number;
  installments: Installment[];
};

/** صنف مادة في كتالوج المواد، بسعر وحدة استرشادي */
export type Material = {
  id: string;
  name: string;
  /** فارغ يعني بلا سعر معرّف — يُدخل يدوياً عند الاستلام */
  unitPrice: number | null;
};

/** سجلّ استلام مواد في موقع مشروع — تتبّع عيني لا قيد محاسبي */
export type MaterialReceipt = {
  id: string;
  date: string;
  fiscalYear: number;
  project: string;
  material: string;
  quantity: number;
  unitPrice: number | null;
  receivedBy: string;
  note: string;
};

/** بيانات الشركة — تظهر في ترويسة كل مطبوعة وسند */
export type CompanyProfile = {
  name: string;
  nameEn: string;
  /** الشعار كـ data URL، حتى يُطبع بلا اتصال بالشبكة */
  logo: string;
  address: string;
  phone: string;
  email: string;
  /** رقم السجل التجاري */
  crNumber: string;
};

export const defaultCompany = (): CompanyProfile => ({
  name: "شركة ذياب للمقاولات",
  nameEn: "",
  logo: "",
  address: "",
  phone: "",
  email: "",
  crNumber: "",
});

export type User = {
  id: string;
  name: string;
  /** الوظيفة كما تُكتب في الشركة */
  jobTitle: string;
  role: RoleKey;
  permissions: Permission[];
  /** تجزئة رقم الدخول — لا يُخزَّن الرقم نفسه أبداً */
  pinHash: string;
  active: boolean;
  createdAt: string;
};

/**
 * تجزئة رقم الدخول بـ SHA-256.
 *
 * هذا يمنع قراءة الرقم من التخزين، لكنه لا يجعل النظام آمناً: التحقق يجري
 * في المتصفح، ومن يفتح أدوات المطوّر يتجاوزه. الحماية الحقيقية تأتي مع
 * الخادم، وهذه البنية تنتقل إليه كما هي.
 */
export async function hashPin(pin: string): Promise<string> {
  const bytes = new TextEncoder().encode(`theyab:${pin}`);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export type AppState = {
  movements: Movement[];
  projects: Project[];
  contractors: Contractor[];
  openingBalances: OpeningBalances;
  materials: Material[];
  materialReceipts: MaterialReceipt[];
  company: CompanyProfile;
  users: User[];
  audit: AuditEntry[];
};

export const SCHEMA_VERSION = 7;

const KEYS = {
  movements: "movements",
  projects: "projects",
  contractors: "contractors",
  openingBalances: "openingBalances",
  materials: "materials",
  materialReceipts: "materialReceipts",
  company: "company",
  users: "users",
  audit: "auditLog",
};

export const emptyState = (): AppState => ({
  movements: [],
  projects: [],
  contractors: [],
  openingBalances: {},
  materials: [],
  materialReceipts: [],
  company: defaultCompany(),
  users: [],
  audit: [],
});

function migrateAudit(raw: unknown): AuditEntry[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((item) => {
      const e = (item ?? {}) as Record<string, unknown>;
      return {
        id: str(e.id) || newId(),
        at: str(e.at),
        user: str(e.user),
        action: str(e.action) as AuditEntry["action"],
        entity: str(e.entity) as AuditEntry["entity"],
        summary: str(e.summary),
        before: e.before == null ? undefined : str(e.before),
        after: e.after == null ? undefined : str(e.after),
      };
    })
    .filter((e) => e.at && e.summary)
    .slice(0, AUDIT_LIMIT);
}

function migrateUser(raw: unknown): User {
  const u = (raw ?? {}) as Record<string, unknown>;
  const role = (["owner", "manager", "secretary", "custom"] as RoleKey[]).includes(
    u.role as RoleKey
  )
    ? (u.role as RoleKey)
    : "custom";

  const stored = Array.isArray(u.permissions) ? (u.permissions as string[]) : [];

  /*
   * دورا المالك والمدير العام معرَّفان بأنهما «كل الصلاحيات بلا استثناء»،
   * فيُمنحان الصلاحيات المضافة حديثاً تلقائياً. بدون هذا يبقى حساب أُنشئ
   * قبل إضافة صلاحية محروماً منها إلى الأبد.
   *
   * أما بقية الأدوار فلا تُمنح شيئاً لم يُقرَّر لها صراحةً — منح صلاحية
   * بلا قرار أخطر من حجبها.
   */
  const permissions =
    role === "owner" || role === "manager"
      ? ALL_PERMISSIONS
      : stored.filter((p): p is Permission =>
          ALL_PERMISSIONS.includes(p as Permission)
        );

  return {
    id: str(u.id) || newId(),
    name: str(u.name),
    jobTitle: str(u.jobTitle),
    role,
    permissions,
    pinHash: str(u.pinHash),
    active: u.active !== false,
    createdAt: str(u.createdAt) || new Date().toISOString(),
  };
}

function migrateCompany(raw: unknown): CompanyProfile {
  const c = (raw ?? {}) as Record<string, unknown>;
  const base = defaultCompany();
  return {
    name: str(c.name) || base.name,
    nameEn: str(c.nameEn),
    logo: str(c.logo),
    address: str(c.address),
    phone: str(c.phone),
    email: str(c.email),
    crNumber: str(c.crNumber),
  };
}

/** تكلفة الاستلام، أو null إن كان سعر الوحدة غير معرّف */
export function receiptCost(receipt: MaterialReceipt): number | null {
  if (receipt.unitPrice == null) return null;
  return round3(receipt.quantity * receipt.unitPrice);
}

export function newId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

const str = (v: unknown, fallback = "") =>
  typeof v === "string" ? v : v == null ? fallback : String(v);

/* ------------------------------------------------------------------ */
/* الترحيل                                                             */
/* ------------------------------------------------------------------ */

function migrateMovement(raw: unknown): Movement {
  const m = (raw ?? {}) as Record<string, unknown>;

  const date = str(m.date);
  const itemCode = str(m.itemCode);
  const itemName = str(m.itemName) || str(m.item);

  // النسخ القديمة لم تكن تخزّن طرفَي القيد، فنشتقهما من البند إن أمكن
  let debitCode = str(m.debitCode);
  let creditCode = str(m.creditCode);
  if (!debitCode && !creditCode) {
    const derived = itemAccount(itemCode || itemName);
    if (derived) debitCode = derived;
  }

  return {
    id: str(m.id) || newId(),
    entryNo: Number(m.entryNo) || 0,
    fiscalYear: Number(m.fiscalYear) || fiscalYearOf(date),
    date,
    movementType: str(m.movementType),
    description: str(m.description),
    itemCode,
    itemName,
    debitCode,
    creditCode,
    amount: round3(Number(m.amount) || 0),
    project: str(m.project),
    person: str(m.person),
    paymentMethod: str(m.paymentMethod),
    party: str(m.party),
    contractNumber: str(m.contractNumber) || undefined,
    installmentNumber: Number(m.installmentNumber) || undefined,
    source: m.source === "excel" ? "excel" : "app",
  };
}

function migrateProject(raw: unknown): Project {
  const p = (raw ?? {}) as Record<string, unknown>;
  return {
    id: str(p.id) || newId(),
    name: str(p.name),
    budget: round3(Number(p.budget) || 0),
    status: str(p.status, "نشط") || "نشط",
  };
}

function migrateContractor(raw: unknown): Contractor {
  const c = (raw ?? {}) as Record<string, unknown>;
  const installments = Array.isArray(c.installments) ? c.installments : [];
  return {
    id: str(c.id) || newId(),
    name: str(c.name),
    specialty: str(c.specialty),
    phone: str(c.phone),
    project: str(c.project),
    contractNumber: str(c.contractNumber),
    contractType: str(c.contractType),
    workType: str(c.workType),
    contractValue: round3(Number(c.contractValue) || 0),
    installmentsCount: Number(c.installmentsCount) || installments.length,
    installments: installments.map((i, index) => {
      const item = (i ?? {}) as Record<string, unknown>;
      const status = str(item.status, "غير مستحقة") || "غير مستحقة";
      return {
        number: Number(item.number) || index + 1,
        value: str(item.value),
        condition: str(item.condition),
        status,
        // البيانات القديمة: الدفعة المدفوعة تعني أن مرحلتها اعتُمدت ضمناً
        approved:
          typeof item.approved === "boolean"
            ? item.approved
            : status.includes("مدفوع"),
        approvedBy: str(item.approvedBy),
        approvedAt: str(item.approvedAt),
        approvalNote: str(item.approvalNote),
      };
    }),
  };
}

const optionalPrice = (v: unknown): number | null => {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? round3(n) : null;
};

function migrateMaterial(raw: unknown): Material {
  const m = (raw ?? {}) as Record<string, unknown>;
  return {
    id: str(m.id) || newId(),
    name: str(m.name),
    unitPrice: optionalPrice(m.unitPrice),
  };
}

function migrateReceipt(raw: unknown): MaterialReceipt {
  const r = (raw ?? {}) as Record<string, unknown>;
  const date = str(r.date);
  return {
    id: str(r.id) || newId(),
    date,
    fiscalYear: Number(r.fiscalYear) || fiscalYearOf(date),
    project: str(r.project),
    material: str(r.material),
    quantity: round3(Number(r.quantity) || 0),
    unitPrice: optionalPrice(r.unitPrice),
    receivedBy: str(r.receivedBy),
    note: str(r.note),
  };
}

const isAccountCode = (key: string) => /^\d{4}$/.test(key);
const isYearKey = (key: string) => /^\d{4}$/.test(key) && Number(key) > 1990;

function migrateYearOpening(raw: unknown): YearOpening {
  if (!raw || typeof raw !== "object") return {};
  const out: YearOpening = {};
  for (const [code, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!isAccountCode(code)) continue;
    const v = (value ?? {}) as Record<string, unknown>;
    out[code] = { debit: str(v.debit), credit: str(v.credit) };
  }
  return out;
}

/**
 * الأرصدة الافتتاحية صارت مفهرسة بالسنة. البيانات القديمة كانت مسطّحة
 * (رقم الحساب مباشرة)، فتُنسب إلى السنة الحالية.
 */
function migrateOpeningBalances(raw: unknown): OpeningBalances {
  if (!raw || typeof raw !== "object") return {};
  const entries = Object.entries(raw as Record<string, unknown>);
  if (entries.length === 0) return {};

  const looksFlat = entries.some(([key, value]) => {
    if (!isAccountCode(key)) return false;
    const v = (value ?? {}) as Record<string, unknown>;
    return "debit" in v || "credit" in v;
  });

  if (looksFlat) {
    return { [String(new Date().getFullYear())]: migrateYearOpening(raw) };
  }

  const out: OpeningBalances = {};
  for (const [year, value] of entries) {
    if (!isYearKey(year)) continue;
    out[year] = migrateYearOpening(value);
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* التحميل والحفظ                                                      */
/* ------------------------------------------------------------------ */

export type LoadResult = { state: AppState; errors: string[] };

function readKey(key: string, errors: string[]): unknown {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch {
    // بيانات تالفة: لا نُسقط التطبيق ولا نمحو الأصل — نُبلغ فقط
    errors.push(`تعذّرت قراءة «${key}» من التخزين المحلي (بيانات تالفة).`);
    return null;
  }
}

export function loadState(): LoadResult {
  const errors: string[] = [];
  const state = emptyState();
  if (typeof window === "undefined") return { state, errors };

  const movements = readKey(KEYS.movements, errors);
  if (Array.isArray(movements)) state.movements = movements.map(migrateMovement);

  const projects = readKey(KEYS.projects, errors);
  if (Array.isArray(projects)) state.projects = projects.map(migrateProject);

  const contractors = readKey(KEYS.contractors, errors);
  if (Array.isArray(contractors))
    state.contractors = contractors.map(migrateContractor);

  state.openingBalances = migrateOpeningBalances(
    readKey(KEYS.openingBalances, errors)
  );

  const materials = readKey(KEYS.materials, errors);
  if (Array.isArray(materials)) state.materials = materials.map(migrateMaterial);

  const receipts = readKey(KEYS.materialReceipts, errors);
  if (Array.isArray(receipts))
    state.materialReceipts = receipts.map(migrateReceipt);

  state.company = migrateCompany(readKey(KEYS.company, errors));

  const users = readKey(KEYS.users, errors);
  if (Array.isArray(users)) state.users = users.map(migrateUser);

  state.audit = migrateAudit(readKey(KEYS.audit, errors));

  return { state, errors };
}

export function saveState(state: AppState): string | null {
  try {
    localStorage.setItem(KEYS.movements, JSON.stringify(state.movements));
    localStorage.setItem(KEYS.projects, JSON.stringify(state.projects));
    localStorage.setItem(KEYS.contractors, JSON.stringify(state.contractors));
    localStorage.setItem(
      KEYS.openingBalances,
      JSON.stringify(state.openingBalances)
    );
    localStorage.setItem(KEYS.materials, JSON.stringify(state.materials));
    localStorage.setItem(
      KEYS.materialReceipts,
      JSON.stringify(state.materialReceipts)
    );
    localStorage.setItem(KEYS.company, JSON.stringify(state.company));
    localStorage.setItem(KEYS.users, JSON.stringify(state.users));
    localStorage.setItem(KEYS.audit, JSON.stringify(state.audit));
    return null;
  } catch {
    return "تعذّر الحفظ في التخزين المحلي — قد تكون المساحة ممتلئة.";
  }
}

/* ------------------------------------------------------------------ */
/* النسخ الاحتياطي                                                     */
/* ------------------------------------------------------------------ */

export function exportBackup(state: AppState): string {
  return JSON.stringify(
    {
      app: "Theyab Accounting",
      schemaVersion: SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      data: state,
    },
    null,
    2
  );
}

export function backupFileName(): string {
  const now = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `theyab-accounting-${now.getFullYear()}-${pad(
    now.getMonth() + 1
  )}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}.json`;
}

export function parseBackup(text: string): AppState {
  const parsed = JSON.parse(text) as Record<string, unknown>;
  const data = (parsed.data ?? parsed) as Record<string, unknown>;
  if (!data || typeof data !== "object") {
    throw new Error("الملف لا يحتوي على بيانات صالحة");
  }

  const state = emptyState();
  if (Array.isArray(data.movements))
    state.movements = data.movements.map(migrateMovement);
  if (Array.isArray(data.projects))
    state.projects = data.projects.map(migrateProject);
  if (Array.isArray(data.contractors))
    state.contractors = data.contractors.map(migrateContractor);
  state.openingBalances = migrateOpeningBalances(data.openingBalances);
  if (Array.isArray(data.materials))
    state.materials = data.materials.map(migrateMaterial);
  if (Array.isArray(data.materialReceipts))
    state.materialReceipts = data.materialReceipts.map(migrateReceipt);
  if (data.company) state.company = migrateCompany(data.company);
  if (Array.isArray(data.users)) state.users = data.users.map(migrateUser);
  state.audit = migrateAudit(data.audit);

  return state;
}
